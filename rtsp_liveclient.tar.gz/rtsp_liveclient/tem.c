#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/prctl.h>
#include <time.h>
#include "list.h"
#include "tem.h"

#define AddTime(ts, ms)                         \
    do{                                             \
        if((ms) >= 1000)                               \
        {                                           \
            ts.tv_sec += (ms) / 1000;                 \
        }                                           \
        ts.tv_nsec += (((ms) % 1000)*1000000);        \
        if(ts.tv_nsec >= 1000000000)                \
        {                                           \
            ts.tv_sec++;                            \
            ts.tv_nsec = ts.tv_nsec - 1000000000;   \
        }                                           \
    }while(0);

#ifndef PTH_RET_CHK
    // Just Temp Solution
#define PTH_RET_CHK(_pf_) \
        ({ \
            int r = _pf_; \
            if ((r != 0) && (r != ETIMEDOUT)) \
                printf("[PTHREAD] %s: %d: %s\n", __FILE__, __LINE__, #_pf_); \
            r; \
        })
#endif

#define TEM_DBG_DEBUG(fmt, args...) //printf(fmt, ##args);
#define TEM_DBG_TRACE(fmt, args...) //printf(fmt, ##args);
#define TEM_DBG_INFO(fmt, args...) //printf(fmt, ##args);
#define TEM_DBG_WARN(fmt, args...) printf(fmt, ##args);
#define TEM_DBG_ERROR(fmt, args...) printf(fmt, ##args);
#define TEM_DBG_FUNCTION_ENTER(fmt, args...) //printf(fmt, ##args);
#define TEM_DBG_FUNCTION_EXIT_OK(fmt, args...) //printf(fmt, ##args);
#define TEM_DBG_FUNCTION_EXIT_ERROR(fmt, args...) //printf(fmt, ##args);
#define MUTEXCHECK(x) \
    do{   \
        if (x != 0)\
        {\
            fprintf( stderr, "%s <%d>:\n\t", __FILE__, __LINE__ ); \
        }\
    } while(0);

#if 1
//TEM: Thread event manager, Writed by Alias.Peng from MStar semiconductor
// Start######
typedef enum{
    E_TEM_IDLE,
    E_TEM_DO_USER_DATA,
    E_TEM_EXIT,
    E_TEM_START_MONITOR,
    E_TEM_START_ONESHOT,
    E_TEM_STOP,
}EN_TEM_STATUS;

typedef struct ST_TEM_DATA_NODE_s{
    EN_TEM_STATUS enTemThrSt;  //Thread status.
    ST_TEM_USER_DATA stUserData; //User data
    struct list_head stDataList; //Data list node
}ST_TEM_DATA_NODE;

typedef struct{
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    pthread_t thread;
    pthread_condattr_t cond_attr;
    pthread_mutexattr_t mutex_attr;
}ST_TEM_INFO;

typedef struct ST_TEM_NODE_s{
    char *pThreadName;     // Tem thread name.
    ST_TEM_ATTR *pTemAttr; // User setting.
    ST_TEM_INFO *pTemInfo; // Info of thread.
    struct list_head stDataListHead; // Tem data event list head of ST_TEM_DATA_NODE.
    MI_U32 u32DataListCnt;
    MI_U32 u32DataListSize;
    struct list_head stTemNodeList; // Tem node.
}ST_TEM_NODE;

static pthread_mutex_t m_MutexTem = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t m_MutexTemEvent = PTHREAD_MUTEX_INITIALIZER;
MI_U32 Mif_Syscfg_GetTime0()
{
    struct timespec ts;
    MI_U32 ms;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    ms = (ts.tv_sec * 1000) + (ts.tv_nsec / 1000000);
    if(ms == 0)
    {
        ms = 1;
    }
    return ms;
}
LIST_HEAD(stTemNodeHead); // Tem node, head of ST_TEM_NODE.

static MI_BOOL _TemPushEvent(ST_TEM_NODE *pTemNode, EN_TEM_STATUS enStatus, ST_TEM_USER_DATA *pstData)
{
    ST_TEM_DATA_NODE *pNode = NULL;

    if (pTemNode == NULL)
    {
        TEM_DBG_ERROR("pTemNode  is NULL!!\n");
        return FALSE;
    }

    MUTEXCHECK(pthread_mutex_lock(&m_MutexTemEvent));
    pNode = (ST_TEM_DATA_NODE *)malloc(sizeof(ST_TEM_DATA_NODE));
    ASSERT(pNode);
    //printf("Malloc %lu\n", (unsigned long)pNode);
    if (pstData != NULL)
    {
        memcpy(&pNode->stUserData, pstData, sizeof(ST_TEM_USER_DATA));
    }
    pNode->enTemThrSt = enStatus;
    list_add_tail(&pNode->stDataList, &pTemNode->stDataListHead);
    pTemNode->u32DataListCnt++;
    pTemNode->u32DataListSize += pNode->stUserData.u32UserDataSize;
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTemEvent));
    return TRUE;
}
static EN_TEM_STATUS _TemPopEvent(ST_TEM_NODE *pTemNode, ST_TEM_USER_DATA *pstData)
{
    ST_TEM_DATA_NODE *pNode = NULL;
    EN_TEM_STATUS enRev = E_TEM_IDLE;

    if (pTemNode == NULL)
    {
        TEM_DBG_ERROR("pTemNode  is NULL!!\n");
        return E_TEM_IDLE;
    }
    if (pstData == NULL)
    {
        TEM_DBG_ERROR("pstData  is NULL!!\n");
        return E_TEM_IDLE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTemEvent));
    if (list_empty(&pTemNode->stDataListHead))
    {
		MUTEXCHECK(pthread_mutex_unlock(&m_MutexTemEvent));
        return E_TEM_IDLE;
    }
    pNode = list_entry(pTemNode->stDataListHead.next, ST_TEM_DATA_NODE, stDataList);
    enRev = pNode->enTemThrSt;
    memcpy(pstData, &pNode->stUserData, sizeof(ST_TEM_USER_DATA));
    list_del(&pNode->stDataList);
    //printf("Free %lu\n", (unsigned long)pNode);
    pTemNode->u32DataListCnt--;
    pTemNode->u32DataListSize -= pNode->stUserData.u32UserDataSize;

    free(pNode);
    if (pTemNode->u32DataListCnt)
    {
        //TEM_DBG_WARN("Buffer poll cnt %d\n", pTemNode->u32DataListCnt);
        //TEM_DBG_WARN("Buffer poll size %d\n", pTemNode->u32DataListSize);
    }
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTemEvent));
    return enRev;
}
static void *_TemThreadMain(void * pArg)
{
    ST_TEM_NODE *pTempNode = (ST_TEM_NODE *)pArg;
    ST_TEM_DATA_NODE *pstDataNode = NULL;
    int intCondWaitRev = 0;
    struct timespec stOuttime;
    MI_BOOL bRunOneShot = FALSE;
    MI_BOOL bOneShotReady = FALSE;
    MI_U32 u32FuncRunTime = 0;
    MI_BOOL bRun = TRUE;
    MI_U32 u32TimeOut = 0;

    if(pTempNode == NULL)
    {
        TEM_DBG_ERROR("Error pArg is NULL!!\n");
        return NULL;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    prctl(PR_SET_NAME, (unsigned long)pTempNode->pThreadName);
    memset(&stOuttime, 0, sizeof(struct timespec));
    while (1)
    {
        u32FuncRunTime = Mif_Syscfg_GetTime0();
        if ((intCondWaitRev == ETIMEDOUT)  \
                && pTempNode->pTemAttr->fpThreadWaitTimeOut)
        {
            if (bRunOneShot == TRUE)
            {
                if (bOneShotReady == FALSE)
                {
                    pTempNode->pTemAttr->fpThreadWaitTimeOut(pTempNode->pTemAttr->stTemBuf, &pTempNode->pTemInfo->mutex);
                    bOneShotReady = TRUE;
                }
            }
            else
            {
                pTempNode->pTemAttr->fpThreadWaitTimeOut(pTempNode->pTemAttr->stTemBuf, &pTempNode->pTemInfo->mutex);
            }
        }
        ST_TEM_USER_DATA stData;
        EN_TEM_STATUS enTemThrSt;
        while (1)
        {
            enTemThrSt = _TemPopEvent(pTempNode, &stData);
			//printf("enTemThrSt: %d\n",enTemThrSt);
			if (E_TEM_IDLE == enTemThrSt)
			{
				break;
			}
            switch (enTemThrSt)
            {
                case E_TEM_EXIT:
                    {
                        TEM_DBG_INFO("Exit thread id:[%x], name[%s]\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName);
                        bRun = FALSE;
                        u32TimeOut = 0;
                    }
                    break;
                case E_TEM_STOP:
                    {
                        TEM_DBG_INFO("Stop thread id:[%x], name[%s]\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName);
                        u32TimeOut = 0;
                    }
                    break;
                case E_TEM_START_MONITOR:
                    {
                        TEM_DBG_INFO("Start thread monitor id:[%x], name[%s]\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName);
                        u32TimeOut = pTempNode->pTemAttr->u32ThreadTimeoutMs;
                    }
                    break;
                case E_TEM_START_ONESHOT:
                    {
                        TEM_DBG_INFO("Start one shot thread id:[%x], name[%s]\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName);
                        bRunOneShot = TRUE;
                        bOneShotReady = FALSE;
                        u32TimeOut = pTempNode->pTemAttr->u32ThreadTimeoutMs;
                    }
                    break;
                case E_TEM_DO_USER_DATA:
                    {
                        if (pTempNode->pTemAttr->fpThreadDoSignal)
                        {
                            TEM_DBG_INFO("Do user data thread id:[%x], name[%s]\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName);
                            pTempNode->pTemAttr->fpThreadDoSignal(pTempNode->pTemAttr->stTemBuf, stData, &pTempNode->pTemInfo->mutex);
                            if (stData.u32UserDataSize != 0)
                            {
								//printf("Free buffer %lu\n", (unsigned long)stData.pUserData);
                                free(stData.pUserData);
                                stData.pUserData = NULL;
                            }
                        }
                    }
                    break;
                default:
                    {
                        TEM_DBG_ERROR("Error tem thread event.id:[%x], name[%s]![%d]",  (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName, enTemThrSt);
                    }
                    break;
            }
        }
        if (bRun == FALSE)
        {
            TEM_DBG_INFO("TEM name [%s]: Bye bye~\n", pTempNode->pThreadName);
            break;
        }
        u32FuncRunTime = Mif_Syscfg_GetTime0() - u32FuncRunTime;
        if (u32TimeOut != 0)
        {
            struct timespec stCurTime;
            clock_gettime(CLOCK_MONOTONIC, &stCurTime);
            if ((stCurTime.tv_sec > stOuttime.tv_sec) \
                    ||((stCurTime.tv_sec == stOuttime.tv_sec)?((stCurTime.tv_nsec >= stOuttime.tv_nsec)?TRUE:FALSE):FALSE) \
                    || pTempNode->pTemAttr->bSignalResetTimer)

            {
                /*         Case TRUE:
                 *                   Reset timer flag  is on.
                 *                   Current time is later than or  equal  the pthread wait time(stOuttime).
                 *                   In this case stOuttime will do stCurTime+u32ThreadTimeoutMs
                 *          Case FALSE:
                 *                   Current time is smaller than the pthread wait time(stOuttime).
                 *                   This case must be get cond signal while waitting time out .
                 *          When first run, and stOuttime is zero and current time is definally larger.
                 */
                memcpy(&stOuttime, &stCurTime, sizeof(struct timespec));
                if (u32FuncRunTime < u32TimeOut)
                {
                    AddTime(stOuttime, u32TimeOut-u32FuncRunTime);
                }
                else
                {
                    AddTime(stOuttime, u32TimeOut);
                    TEM_DBG_WARN("Func run time is too much, and it's larger than monitor wait time!!\n ");
                }
            }

            intCondWaitRev = pthread_cond_timedwait(&pTempNode->pTemInfo->cond, &pTempNode->pTemInfo->mutex, &stOuttime);
        }
        else
        {
            intCondWaitRev = pthread_cond_wait(&pTempNode->pTemInfo->cond, &pTempNode->pTemInfo->mutex);
        }
        //TEM_DBG_INFO("thread id:[%x], name[%s] Func run time %d\n", (int)pTempNode->pTemInfo->thread, pTempNode->pThreadName, u32FuncRunTime);
    }
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));

    return NULL;
}
static struct list_head *_TemFindFp(struct list_head *pstPos, void *pKey)
{
    ST_TEM_NODE *pstNode =  list_entry(pstPos, ST_TEM_NODE, stTemNodeList);
    char *pName = (char *)pKey;

    return strcmp(pName, pstNode->pThreadName)?pstPos->next:pstPos;
}
static ST_TEM_NODE *_TemFindNode(const char* pStr)
{
    ST_TEM_NODE *pTemp = NULL;
    struct list_head *pList = NULL;

    pList = list_find(&stTemNodeHead, (void *)pStr, _TemFindFp);
    if (pList != &stTemNodeHead)
    {
        pTemp = list_entry(pList, ST_TEM_NODE, stTemNodeList);
    }
    else
    {
        TEM_DBG_ERROR("Not found compaired list: %s\n", pStr);
    }

    return pTemp;
}
static ST_TEM_NODE *_TemAddNode(const char* pStr, ST_TEM_ATTR stAttr)
{
    ST_TEM_NODE *pTemp = NULL;

    pTemp = (ST_TEM_NODE *)malloc(sizeof(ST_TEM_NODE));
    ASSERT(pTemp);
    memset(pTemp, 0, sizeof(ST_TEM_NODE));

    /*Malloc thread name buffer.*/
    pTemp->pThreadName = (char *)malloc(strlen(pStr) + 1);
    ASSERT(pTemp->pThreadName);
    memset(pTemp->pThreadName, 0, strlen(pStr) + 1);
    strcpy(pTemp->pThreadName, pStr);
    /*End*/

    /*Malloc Tem Attr buffer*/
    pTemp->pTemAttr = (ST_TEM_ATTR *)malloc(sizeof(ST_TEM_ATTR));
    ASSERT(pTemp->pTemAttr);
    memset(pTemp->pTemAttr, 0, sizeof(ST_TEM_ATTR));
    memcpy(pTemp->pTemAttr, &stAttr, sizeof(ST_TEM_ATTR));
    /*End*/

    /*Malloc Tem internal buffer size*/
    if (stAttr.stTemBuf.u32TemBufferSize != 0 && stAttr.stTemBuf.pTemBuffer != NULL)
    {
        pTemp->pTemAttr->stTemBuf.pTemBuffer = (void *)malloc(stAttr.stTemBuf.u32TemBufferSize);
        ASSERT(pTemp->pTemAttr->stTemBuf.pTemBuffer);
        memcpy(pTemp->pTemAttr->stTemBuf.pTemBuffer, stAttr.stTemBuf.pTemBuffer, stAttr.stTemBuf.u32TemBufferSize);
    }
    /*End*/

    /*Malloc Tem info*/
    pTemp->pTemInfo = (ST_TEM_INFO *)malloc(sizeof(ST_TEM_INFO));
    ASSERT(pTemp->pTemInfo);
    memset(pTemp->pTemInfo, 0, sizeof(ST_TEM_INFO));
    /*End*/

    /*Init data event list*/
    INIT_LIST_HEAD(&pTemp->stDataListHead);
    /*End*/

    list_add_tail(&pTemp->stTemNodeList, &stTemNodeHead);
    return pTemp;
}
static MI_BOOL _TemDelNode(const char* pStr)
{
    ST_TEM_NODE *pTemp = NULL;

    pTemp = _TemFindNode(pStr);
    if (pTemp)
    {
        list_del(&pTemp->stTemNodeList);

        free(pTemp->pTemInfo);
        pTemp->pTemInfo = NULL;

        if (pTemp->pTemAttr->stTemBuf.u32TemBufferSize != 0 && pTemp->pTemAttr->stTemBuf.pTemBuffer != NULL)
        {
            free(pTemp->pTemAttr->stTemBuf.pTemBuffer);
            pTemp->pTemAttr->stTemBuf.pTemBuffer = NULL;
        }
        free(pTemp->pTemAttr);
        pTemp->pTemAttr = NULL;

        free(pTemp->pThreadName);
        pTemp->pThreadName = NULL;

        free(pTemp);
        pTemp = NULL;
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}
MI_BOOL TemOpen(const char* pStr, ST_TEM_ATTR stAttr)
{
    ST_TEM_NODE *pTemp = NULL;

    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));

    pTemp = _TemAddNode(pStr, stAttr);
    PTH_RET_CHK(pthread_condattr_init(&(pTemp->pTemInfo->cond_attr)));
    PTH_RET_CHK(pthread_condattr_setclock(&(pTemp->pTemInfo->cond_attr), CLOCK_MONOTONIC));
    PTH_RET_CHK(pthread_mutexattr_init(&(pTemp->pTemInfo->mutex_attr)));
    PTH_RET_CHK(pthread_mutexattr_settype(&(pTemp->pTemInfo->mutex_attr), PTHREAD_MUTEX_RECURSIVE));
    PTH_RET_CHK(pthread_mutex_init(&(pTemp->pTemInfo->mutex), &(pTemp->pTemInfo->mutex_attr)));
    PTH_RET_CHK(pthread_cond_init(&(pTemp->pTemInfo->cond), &(pTemp->pTemInfo->cond_attr)));
    PTH_RET_CHK(pthread_create(&(pTemp->pTemInfo->thread), &(pTemp->pTemAttr->thread_attr), _TemThreadMain, (void *)pTemp));

    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemClose(const char* pStr)
{
    ST_TEM_NODE *pTempNode = NULL;
    void *retval = NULL;

    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr is NULL!!!\n");
        return FALSE;
    }

    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    _TemPushEvent(pTempNode, E_TEM_EXIT, NULL);
    PTH_RET_CHK(pthread_cond_signal(&pTempNode->pTemInfo->cond));
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
    PTH_RET_CHK(pthread_join(pTempNode->pTemInfo->thread, &retval));
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    PTH_RET_CHK(pthread_mutexattr_destroy(&pTempNode->pTemInfo->mutex_attr));
    PTH_RET_CHK(pthread_mutex_destroy(&pTempNode->pTemInfo->mutex));
    PTH_RET_CHK(pthread_condattr_destroy(&pTempNode->pTemInfo->cond_attr));
    PTH_RET_CHK(pthread_cond_destroy(&pTempNode->pTemInfo->cond));
    if (_TemDelNode(pStr) == TRUE)
    {
        TEM_DBG_INFO("Node [%s] delete ok! \n", pStr);
    }
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemStartMonitor(const char* pStr)
{
    ST_TEM_NODE *pTempNode = NULL;

    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    _TemPushEvent(pTempNode, E_TEM_START_MONITOR, NULL);
    PTH_RET_CHK(pthread_cond_signal(&pTempNode->pTemInfo->cond));
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));

    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemStartOneShot(const char* pStr)
{
    ST_TEM_NODE *pTempNode = NULL;

    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    _TemPushEvent(pTempNode, E_TEM_START_ONESHOT, NULL);
    PTH_RET_CHK(pthread_cond_signal(&pTempNode->pTemInfo->cond));
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemConfigTimer(const char* pStr, MI_U32 u32TimeOut, MI_BOOL bSignalResetTimer)
{
    ST_TEM_NODE *pTempNode = NULL;
    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    if (u32TimeOut != 0)
    {
        pTempNode->pTemAttr->u32ThreadTimeoutMs = u32TimeOut;
    }
    pTempNode->pTemAttr->bSignalResetTimer = bSignalResetTimer;

    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
    return TRUE;
}
MI_BOOL TemStop(const char* pStr)
{
    ST_TEM_NODE *pTempNode = NULL;

    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }

    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    _TemPushEvent(pTempNode, E_TEM_STOP, NULL);
    PTH_RET_CHK(pthread_cond_signal(&pTempNode->pTemInfo->cond));
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemSend(const char* pStr, ST_TEM_USER_DATA stUserData)
{
    ST_TEM_NODE *pTempNode = NULL;
    void *pDataBuffer = NULL;

    if(pStr == NULL)
    {
        TEM_DBG_ERROR("pStr or pUserData is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    if (stUserData.u32UserDataSize != 0)
    {
        pDataBuffer = (void *)malloc(stUserData.u32UserDataSize);
        ASSERT(pDataBuffer);
		//printf("Malloc buffer %lu\n", (unsigned long)pDataBuffer);
        memcpy(pDataBuffer, stUserData.pUserData, stUserData.u32UserDataSize);
        stUserData.pUserData = pDataBuffer;
    }
    _TemPushEvent(pTempNode, E_TEM_DO_USER_DATA, &stUserData);
    PTH_RET_CHK(pthread_cond_signal(&pTempNode->pTemInfo->cond));
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemSetBuffer(const char* pStr, void *pBufferData)
{
    ST_TEM_NODE *pTempNode = NULL;

    if(pStr == NULL || pBufferData == NULL)
    {
        TEM_DBG_ERROR("pStr or pBufferData is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    memcpy(pTempNode->pTemAttr->stTemBuf.pTemBuffer, pBufferData, pTempNode->pTemAttr->stTemBuf.u32TemBufferSize);
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemGetBuffer(const char* pStr, void *pBufferData)
{
    ST_TEM_NODE *pTempNode = NULL;

    if(pStr == NULL || pBufferData == NULL)
    {
        TEM_DBG_ERROR("pStr or pBufferData is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    memcpy(pBufferData, pTempNode->pTemAttr->stTemBuf.pTemBuffer, pTempNode->pTemAttr->stTemBuf.u32TemBufferSize);
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}

MI_BOOL TemSetPartBufData(const char* pStr, void *pstBufHeadAddr, void *pstBufPartAddr, MI_U32 u32DataSize)
{
    ST_TEM_NODE *pTempNode = NULL;
    MI_U32 u32AddrOffSide = 0;

    if(pStr == NULL || pstBufHeadAddr == NULL || pstBufPartAddr == NULL || u32DataSize == 0)
    {
        TEM_DBG_ERROR("pStr or pBufferData is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    u32AddrOffSide = pstBufPartAddr - pstBufHeadAddr;
    if (pTempNode->pTemAttr->stTemBuf.u32TemBufferSize != 0 && u32AddrOffSide < pTempNode->pTemAttr->stTemBuf.u32TemBufferSize)
    {
        memcpy(pTempNode->pTemAttr->stTemBuf.pTemBuffer + u32AddrOffSide, pstBufPartAddr, u32DataSize);
    }
    else
    {
        TEM_DBG_ERROR("######Your part of tem buf data addr is error!!!\n");
    }
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}
MI_BOOL TemGetPartBufData(const char* pStr, void *pstBufHeadAddr, void *pstBufPartAddr, MI_U32 u32DataSize)
{
    ST_TEM_NODE *pTempNode = NULL;
    MI_U32 u32AddrOffSide = 0;

    if(pStr == NULL || pstBufHeadAddr == NULL || pstBufPartAddr == NULL || u32DataSize == 0)
    {
        TEM_DBG_ERROR("pStr or pBufferData is NULL!!!\n");
        return FALSE;
    }
    MUTEXCHECK(pthread_mutex_lock(&m_MutexTem));
    pTempNode = _TemFindNode(pStr);
    if (pTempNode == NULL)
    {
        MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));
        return FALSE;
    }
    PTH_RET_CHK(pthread_mutex_lock(&pTempNode->pTemInfo->mutex));
    u32AddrOffSide = pstBufPartAddr - pstBufHeadAddr;
    if (pTempNode->pTemAttr->stTemBuf.u32TemBufferSize != 0 && u32AddrOffSide < pTempNode->pTemAttr->stTemBuf.u32TemBufferSize)
    {
        memcpy(pstBufPartAddr, pTempNode->pTemAttr->stTemBuf.pTemBuffer + u32AddrOffSide, u32DataSize);
    }
    else
    {
        TEM_DBG_ERROR("######Your part of tem buf data addr is error!!!\n");
    }
    PTH_RET_CHK(pthread_mutex_unlock(&pTempNode->pTemInfo->mutex));
    MUTEXCHECK(pthread_mutex_unlock(&m_MutexTem));

    return TRUE;
}

//end###################################################
#endif
