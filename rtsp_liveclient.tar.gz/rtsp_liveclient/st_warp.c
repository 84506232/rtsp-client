#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>

#include "mi_sys.h"
#include "mi_warp.h"

#include "st_common.h"
#include "st_warp.h"

#include "mi_warp_gentable.h"

#define WARP_CFG_PATH   "./Pattern/AMTK_FHD/cfg/AMTK_1R_cm_nv12_I2.cfg"

MI_S32 Warp_SetChnTable(MI_WARP_DEV dev,MI_WARP_CHN ch,MI_WARP_TableType_e eTableType,MI_S8 *pTablePath)
{
    struct stat statbuff;
    MI_U8 *pBufData = NULL;
    MI_S32 s32TableFd = 0;
    MI_U32 u32TableSize = 0;
    
    printf("ST Warp Init!!!\n");

    if (pTablePath == NULL)
    {
        printf("File path null!\n");
        return MI_ERR_WARP_ILLEGAL_PARAM;
    }
    
    memset(&statbuff, 0, sizeof(struct stat));
    if(stat(pTablePath, &statbuff) < 0)
    {
        printf("Bb table file not exit!\n");
        return MI_ERR_WARP_ILLEGAL_PARAM;
    }
    else
    {
        if (statbuff.st_size == 0)
        {
            printf("File size is zero!\n");
            return MI_ERR_WARP_ILLEGAL_PARAM;
        }
        u32TableSize = statbuff.st_size;
    }
    
    s32TableFd = open(pTablePath, O_RDONLY);
    if (s32TableFd < 0)
    {
        printf("Open file[%s] error!\n", s32TableFd);
        return MI_ERR_WARP_ILLEGAL_PARAM;
    }
    
    pBufData = (MI_U8 *)malloc(u32TableSize);
    if (!pBufData)
    {
        printf("Malloc error!\n");
        close(s32TableFd);

        return MI_ERR_WARP_ILLEGAL_PARAM;
    }

    read(s32TableFd, pBufData, u32TableSize);
    close(s32TableFd);

    ExecFunc(MI_WARP_SetChnTable(dev, ch, eTableType, pBufData, u32TableSize),MI_WARP_OK);

    free(pBufData);

    return MI_SUCCESS;
}
MI_S32 ST_Warp_Init(MI_WARP_DEV dev,MI_WARP_CHN ch)
{

    Warp_SetChnTable(dev,ch,MI_WARP_BOUND_BOX_TABLE, "./bb_table.bin");
    Warp_SetChnTable(dev,ch,MI_WARP_DISP_ABSOLUTE_TABLE, "././map_yx.bin");
#if 0
    unsigned char* pWorkingBuffer;
    int working_buf_len = 0;

    mi_WARP_para twarp_para;
	WARP_DIS_BIN_HANDLE twarp_dis_bin;
	WARP_BB_BIN_HANDLE twarp_bb_bin;
    mi_WARP_config_param tconfig_para;
    mi_WARP_err err_state = MI_WARP_ERR_NONE;
    WARP_DEV_HANDLE warp_handle = NULL;

    //pasing config. file
    err_state = mi_WARP_config_parse(WARP_CFG_PATH, (mi_WARP_config_param*)&tconfig_para);
    if (err_state != MI_WARP_ERR_NONE)
    {
        printf("config file read error: %d\n", err_state);
        return err_state;
    }

    //get buffer length and allocate working buffer.
    working_buf_len = mi_WARP_get_buffer_info((mi_WARP_config_param*)&tconfig_para);
    pWorkingBuffer = (unsigned char*)malloc(working_buf_len);
    if (pWorkingBuffer == NULL)
    {
        printf("buffer allocate error\n");
        return MI_WARP_ERR_MEM_ALLOCATE_FAIL;
    }

    //warp init
    twarp_para.ptconfig_para = (mi_WARP_config_param*)&tconfig_para; //warp configure
    warp_handle = mi_WARP_runtime_init(pWorkingBuffer, working_buf_len, &twarp_para);
    if (warp_handle == NULL)
    {
        printf("EPTZ init error\n");
        return MI_WARP_ERR_NOT_INIT;
    }

    //select mode
    switch (tconfig_para.WARP_mode)
    {
        case WARP_MODE_4R_CM:  //WARP_MODE_4R_CM/Desk, if in desk mount mode, tilt is nagetive.
            //Gen bin files from 0 to 360 degree
            twarp_para.view_index = 1;
            twarp_para.pan = 0;
            twarp_para.tilt = -50; //In CM mode, tilt is positive, but in desk mode, tilt is negative.
            twarp_para.rotate = 0;
            twarp_para.zoom = 150;
            twarp_para.out_rot = 0;
            break;
        case WARP_MODE_4R_WM:  //WARP_MODE_4R_WM
            //Gen bin files from 0 to 360 degree
            twarp_para.view_index = 1;
            twarp_para.pan = 0;
            twarp_para.tilt = 50; //In CM mode, tilt is positive, but in desk mode, tilt is negative.
            twarp_para.rotate = 0;
            twarp_para.zoom = 150;
            twarp_para.out_rot = 0;
            break;

        case WARP_MODE_1R:  //WARP_MODE_1R CM/Desk,  if in desk mount mode, tilt is negative.
            twarp_para.view_index = 0;
            twarp_para.pan = 0;
            twarp_para.tilt = -65; //In CM mode, tilt is positive, but in desk mode, tilt is negative.
            twarp_para.rotate = 90;
            twarp_para.zoom = 150;
            twarp_para.out_rot = 0;
            break;

        case WARP_MODE_1R_WM:  //WARP_MODE_1R_WM WM
            twarp_para.view_index = 0;
            twarp_para.pan = 0;
            twarp_para.tilt = 50; //In CM mode, tilt is positive, but in desk mode, tilt is negative.
            twarp_para.rotate = 45;
            twarp_para.zoom = 150;
            twarp_para.out_rot = 0;
            break;

        case WARP_MODE_2P_CM:  //WARP_MODE_2P_CM
        case WARP_MODE_2P_DM:  //WARP_MODE_2P_DM
        case WARP_MODE_1P_CM:  //WARP_MODE_1P_CM
            //Degree 180 ~ 0
            twarp_para.view_index = 1;
            twarp_para.r_inside = 10;
            twarp_para.r_outside = 550;
            twarp_para.theta_start = 180;
            twarp_para.theta_end = 0;
            break;

        case WARP_MODE_1P_WM:  //WARP_MODE_1P wall mount.
            twarp_para.view_index = 0;
            twarp_para.pan = 0;
            twarp_para.tilt = 0;
            twarp_para.zoom_h = 100;
            twarp_para.zoom_v = 100;
            break;

        default:  //LDC_MODE_1R
            twarp_para.view_index = 0;
            twarp_para.pan = 0;
            twarp_para.tilt = 0;  //In CM mode, tilt is positive, but in desk mode, tilt is negative.
            twarp_para.rotate = 0;
            twarp_para.zoom = 150;
            twarp_para.out_rot = 0;
            break;
    }//end select mode

    //Runtime to gen bin file
    err_state = (mi_WARP_err)mi_warp_runtime_map_gen(warp_handle, (mi_WARP_para*)&twarp_para, (WARP_DIS_BIN_HANDLE*)&twarp_dis_bin, (WARP_BB_BIN_HANDLE*)&twarp_bb_bin);
    if (err_state != MI_WARP_ERR_NONE)
    {
        printf("[EPTZ ERR] =  %d !! \n", err_state);
    }

    MI_U8 *pTmp;
    int id,size;
    pTmp = malloc(sizeof(int)); 
    if (pTmp == NULL)
    {
        printf("pTmp allocate error!!\n");
        goto Exit;
    }

    memcpy(pTmp,twarp_dis_bin,sizeof(int));
    id = *pTmp;
    memcpy(pTmp,twarp_dis_bin+sizeof(int),sizeof(int));
    size = *pTmp;
    printf("disp id: %d ,size: %d\n",id,size);
    
    ExecFunc(MI_WARP_SetChnTable(dev, ch, MI_WARP_DISP_ABSOLUTE_TABLE, twarp_dis_bin, size),MI_WARP_OK);
    
    memcpy(pTmp,twarp_bb_bin,sizeof(int));
    size = *pTmp;
    printf("bb size: %d\n",size);
    free(pTmp);
    
    ExecFunc(MI_WARP_SetChnTable(dev, ch, MI_WARP_BOUND_BOX_TABLE, twarp_bb_bin, size),MI_WARP_OK);
Exit:
    //Free bin buffer
    err_state = mi_WARP_buffer_free((WARP_DIS_BIN_HANDLE)twarp_dis_bin, (WARP_BB_BIN_HANDLE)twarp_bb_bin);
    if (err_state != MI_WARP_ERR_NONE)
    {
        printf("[MI EPTZ ERR] =  %d !! \n", err_state);
    }

     //release working buffer
    free(pWorkingBuffer);
#endif
    return MI_SUCCESS;
}

MI_S32 ST_Warp_Exit(void)
{
    ExecFunc(MI_WARP_StopDev(0), MI_WARP_OK);
    ExecFunc(MI_WARP_DestroyDevice(0), MI_WARP_OK);

    return MI_SUCCESS;
}

MI_S32 ST_Warp_CreateChannel(MI_WARP_CHN warpChn)
{

    ExecFunc(MI_WARP_CreateChannel(0, warpChn), MI_WARP_OK);

    return MI_SUCCESS;
}

MI_S32 ST_Warp_DestroyChannel(MI_WARP_CHN warpChn)
{
    ExecFunc(MI_WARP_DestroyChannel(0, warpChn), MI_WARP_OK);

    return MI_SUCCESS;
}


