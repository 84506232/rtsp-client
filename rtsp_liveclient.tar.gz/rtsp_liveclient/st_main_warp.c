#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <signal.h>

#include <poll.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/resource.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>

#include<sys/time.h>
#include<unistd.h>

#include <assert.h>
#include <ctype.h>


#include <sys/socket.h>
#include <netinet/in.h>


#include "mi_sys.h"
#include "mi_vdec.h"
#include "mi_divp.h"
#include "mi_disp.h"

#include "mi_venc.h"
#include "mi_common.h"

#include "st_common.h"
#include "st_hdmi.h"
#include "st_warp.h"

#define DISP_XPOS_ALIGN     2
#define DISP_YPOS_ALIGN     2
#define DISP_WIDTH_ALIGN    2
#define DISP_HEIGHT_ALIGN   2

#define DST_FRAME 30
#define SRC_FRAME 30

#define DO_ONE_FRAME    0

typedef struct
{
    void *pInFrame;
    MI_S32 s32Size;
    
} InputData_t;


static void *WarpInputFunc0(void *args)
{   
    struct pollfd pfd = {0};
    pfd.fd = 0;
    pfd.events = POLLIN | POLLERR;
    int index = 0;

    MI_SYS_ChnPort_t stChnPort = {0};
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 0;
    stChnPort.u32PortId = 0;
    //MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 7);
    char szFileName[64];
    memset(szFileName, 0, sizeof(szFileName));
    sprintf(szFileName, "./warp%d.yuv", index);
    int fd = open(szFileName, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | O_APPEND);
    if (fd < 0) {
        printf("%s open \n", __FUNCTION__);
        return;
    }
            
    
    if (MI_SUCCESS != MI_SYS_GetFd(&stChnPort, (MI_S32 *)&pfd.fd)) 
    {
        printf("%s MI_SYS_GetFd fail\n", __FUNCTION__);
        return 0;
    } 
    else 
    {
        while (1)
        {

            int rval = poll(&pfd, 1, 200);
            if (rval < 0) {
                printf("%s poll error!\n", __FUNCTION__);
                break;
            } else if (rval == 0) {
                printf("%s get fd time out!\n", __FUNCTION__);
                continue;
            }

            MI_SYS_BUF_HANDLE hHandle;
            MI_SYS_BufInfo_t stBufInfo;

            MI_S32 s32Ret = MI_SYS_ChnOutputPortGetBuf(&stChnPort, &stBufInfo, &hHandle);
            if (s32Ret) {
                printf("%s MI_SYS_ChnOutputPortGetBuf %d!\n", __FUNCTION__, s32Ret);
                break;
            }

            printf("output size: %d\n",stBufInfo.stFrameData.u32BufSize);
            
            write(fd, stBufInfo.stFrameData.pVirAddr[0], stBufInfo.stFrameData.u32BufSize*2/3);
            write(fd, stBufInfo.stFrameData.pVirAddr[1], stBufInfo.stFrameData.u32BufSize/3);
            
            
            MI_SYS_ChnOutputPortPutBuf(hHandle);

        }
        }
    
        if (MI_SUCCESS != MI_SYS_CloseFd(pfd.fd))
        {
            printf("MI_SYS_CloseFd fail\n");
        }
        close(fd);
        printf("%s E\n", __FUNCTION__);
        return 0;

}

static void *WarpInputFunc1(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 1;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc2(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 2;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc3(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 3;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc4(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 4;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc5(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 5;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc6(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 6;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc7(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 7;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc8(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 8;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}


int main(int argc, const char *argv[])
{
    //init warp
    MI_SYS_ChnPort_t stChnPort;
    MI_WARP_DEV dev = 0;
    MI_WARP_CHN ch = 0;
    int i;
    
    ExecFunc(MI_WARP_CreateDevice(dev), MI_WARP_OK);
    ExecFunc(MI_WARP_StartDev(dev), MI_WARP_OK);

    STCHECKRESULT(ST_Warp_Init(dev,ch,E_WARP_2560_1920_NV12));
    /************************************************
    Step6:  init Warp
    *************************************************/
    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = ch;
    stChnPort.u32PortId = 0;
    MI_SYS_SetChnOutputPortDepth(&stChnPort, 5, 7);
    STCHECKRESULT(ST_Warp_CreateChannel(ch)); //default support port2 --->>> venc

    MI_WARP_PortSize_t stPortInfo;
    stPortInfo.u16Width = 640;
    stPortInfo.u16Height = 360;
    MI_WARP_SetOutPortSize(dev, ch, stPortInfo);
    

    char szSrcFilePath[256];
    MI_S32 s32Size = 0;
    FILE *pSrcFile = NULL;
    void *pInFrame = NULL;
    
    memset(szSrcFilePath, 0, sizeof(szSrcFilePath));
    
    sprintf(szSrcFilePath, "%s", argv[1]);

    pSrcFile = fopen(szSrcFilePath, "r");
    if (!pSrcFile)
    {
        printf("open srcFile %s failed\n", szSrcFilePath);
        return 0;
    }

    fseek(pSrcFile, 0, SEEK_END);
    s32Size = ftell(pSrcFile);
    printf("file size is %d\n", s32Size);

    fseek(pSrcFile, 0, SEEK_SET);
    pInFrame = malloc(s32Size);
    memset(pInFrame, 0, s32Size);
    fread(pInFrame, 1, s32Size, pSrcFile);

    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    time_t stTime = 0;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    pthread_t WarpThreadID0;
    pthread_create(&WarpThreadID0, NULL, WarpInputFunc0, NULL);

    while(1)
    {

        memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
        stChnPort.eModId = E_MI_MODULE_ID_WARP;
        stChnPort.u32DevId = 0;
        stChnPort.u32ChnId = 0;
        stChnPort.u32PortId = 0;
        // inject inFrame

        memset(&stBufInfo,0,sizeof(MI_SYS_BufInfo_t));
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            break;
        }
        printf("addr0: %p,addr1: %p,size:%d\n",stBufInfo.stFrameData.pVirAddr[0],stBufInfo.stFrameData.pVirAddr[1],stBufInfo.stFrameData.u32BufSize);
        fseek(pSrcFile, 0, SEEK_SET);
        fread(stBufInfo.stFrameData.pVirAddr[0], 1, s32Size*2/3, pSrcFile);
        fseek(pSrcFile, s32Size*2/3, SEEK_SET);
        fread(stBufInfo.stFrameData.pVirAddr[1], 1, s32Size/3, pSrcFile);

        printf("11 addr0: %p,addr1: %p\n",stBufInfo.stFrameData.pVirAddr[0],stBufInfo.stFrameData.pVirAddr[1]);
        //memcpy(stBufInfo.stFrameData.pVirAddr[0], pInFrame, s32Size*2/3);
        //memcpy(stBufInfo.stFrameData.pVirAddr[1], pInFrame+s32Size*2/3, s32Size/3);
        //MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], s32Size*2/3);
        //MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        //usleep(30*1000);

        
    }


            
    return 0;
}

