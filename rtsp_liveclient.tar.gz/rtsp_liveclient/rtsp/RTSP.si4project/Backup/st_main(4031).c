#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <signal.h>

#include <poll.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/resource.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>

#include<sys/time.h>
#include<unistd.h>

#include <assert.h>
#include <ctype.h>


#include <sys/socket.h>
#include <netinet/in.h>


#include "mi_sys.h"
#include "mi_vdec.h"
#include "mi_divp.h"
#include "mi_disp.h"

#include "mi_venc.h"
#include "mi_common.h"

#include "st_common.h"
#include "st_hdmi.h"
#include "st_warp.h"

#include "RTSP_Stream_API.h"
#include "tem.h"
#include "list.h"

#define ST_DEBUG_INPUT_PARAM 0

#define DISP_XPOS_ALIGN     2
#define DISP_YPOS_ALIGN     2
#define DISP_WIDTH_ALIGN    2
#define DISP_HEIGHT_ALIGN   2

#define DST_FRAME 30
#define SRC_FRAME 30

#define VDISP_FRAME 30
#define SLEEP_TIME 0 * 1000

#define MAX_CYCLE_COUNT 10

#define RTSP_SWITCH_SCREEN_CASE1_SLEEP  3 //3ms
#define RTSP_SWITCH_SCREEN_CASE2_SLEEP  8 //8ms

#define WRITE_PATH "/mnt/ES/chn%d_%ld.%s"   //ChnNum Time Type

#define RTSP_PRT(msg, ...) do{printf("ERR: %s-%d:" msg,__FUNCTION__, __LINE__,##__VA_ARGS__);fflush(stdout); }while(0)

#define CHECK_NULL_POINTER(func, pointer) \
    do\
	{\
	    if(pointer==NULL) \
	    {\
            printf("%s Parameter NULL!Line: %d\n", func, __LINE__);\
            return -1;\
	    }\
	}while(0);

// file config

typedef struct RTSP_Info_s{
    MI_U8 u8ChnStart;
    MI_U8 u8ChnEnd;
    MI_U32 u32PixelWidth;
    MI_U32 u32PixelHeight;
    MI_U32 u32FrameRate;
    MI_VDEC_CodecType_e eVdecType;
    MI_U8  *pu8RtspPath;
    MI_U8  *pu8RtspUserName;
    MI_U8  *pu8RtspPasswd;
    MI_BOOL bInit;
    struct list_head list;
}RTSP_Info_t;

typedef struct
{
    volatile MI_BOOL bResume;
} Main_Context;


static MI_S32 _gs32VoChnNum = 0;
static MI_S32 _gs32VoChnNumTmp = 0;

static ST_Sys_TestParam_t _stTestParam = {0};
static MI_S32 _gs32RtspBreak = 0;
static MI_S32 _gs32StartTrans  = 0;
static int sockfd;



static pthread_mutex_t CallBackMutex; //use for CallBackFunc


#if RTSP_WRITE_FILE
static FILE *_pFile[16];
#endif

LIST_HEAD(RTSP_List);

void ST_RtspPrint(RTSP_Info_t *pstRtspInfo)
{
    printf("ChnStart = #%d#\n", pstRtspInfo->u8ChnStart);
    printf("ChnEnd = #%d#\n", pstRtspInfo->u8ChnEnd);
    printf("Width = #%d#\n", pstRtspInfo->u32PixelWidth);
    printf("Height = #%d#\n", pstRtspInfo->u32PixelHeight);
    printf("FrameRate = #%d#\n", pstRtspInfo->u32FrameRate);
    printf("VdecType = #%d#\n", pstRtspInfo->eVdecType);
    printf("RtspPath = #%s#\n", pstRtspInfo->pu8RtspPath);
    printf("RtspName = #%s#\n", pstRtspInfo->pu8RtspUserName);
    printf("RtspPasswd = #%s#\n", pstRtspInfo->pu8RtspPasswd);
    printf("bInit = %d\n", pstRtspInfo->bInit);
}

int ST_RtspPrintList(void)
{
    struct list_head *pos;
    RTSP_Info_t *RtspInfo = NULL;

    if (list_empty(&RTSP_List))
    {
        printf("list is empty\n");
        return 0;
    }

    list_for_each(pos, &RTSP_List)
    {
        RtspInfo = list_entry(pos, RTSP_Info_t, list);
        ST_RtspPrint(RtspInfo);
        printf("=====================\n");
    }

    return 0;
}

MI_S32 ST_RtspCreateFile(void)
{
    struct list_head *pstPos;
    RTSP_Info_t *pstRtspInfo = NULL;
    MI_U32 u32ChnNum = 0;
    time_t stTime;
    MI_U8 u8FileName[128];

    stTime = time(NULL);
    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        for (u32ChnNum = pstRtspInfo->u8ChnStart; u32ChnNum <= pstRtspInfo->u8ChnEnd; u32ChnNum++)
        {
            if (E_MI_VDEC_CODEC_TYPE_H264 == pstRtspInfo->eVdecType)
            {
                snprintf(u8FileName, 128, WRITE_PATH, u32ChnNum, stTime, "h264");
            }

            if (E_MI_VDEC_CODEC_TYPE_H265 == pstRtspInfo->eVdecType)
            {
                snprintf(u8FileName, 128, WRITE_PATH, u32ChnNum, stTime, "h265");
            }
#if RTSP_WRITE_FILE
            _pFile[u32ChnNum] = fopen(u8FileName, "w+");
            if (NULL == _pFile[u32ChnNum])
            {
                printf("Create File Failed: %s\n", u8FileName);
                sleep(1);
            }
#endif
        }
    }

    return MI_SUCCESS;
}

MI_S32 ST_RtspCloseFile(void)
{
    struct list_head *pstPos;
    RTSP_Info_t *pstRtspInfo = NULL;
    MI_U32 u32ChnNum = 0;

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        for (u32ChnNum = pstRtspInfo->u8ChnStart; u32ChnNum <= pstRtspInfo->u8ChnEnd; u32ChnNum++)
        {
#if RTSP_WRITE_FILE
            fclose(_pFile[u32ChnNum]);
#endif
        }
    }

    return MI_SUCCESS;
}

MI_S32 ST_RtspRelease(void)
{
	struct list_head *pos;
	struct list_head *tmp;
	RTSP_Info_t *pstRtspInfo = NULL;

	if (list_empty(&RTSP_List))
	{
		printf("list is empty\n");
		return 0;
	}

	list_for_each_safe(pos, tmp, &RTSP_List)
	{
		pstRtspInfo = list_entry(pos, RTSP_Info_t, list);

		free(pstRtspInfo->pu8RtspPath);
		free(pstRtspInfo->pu8RtspPasswd);
		free(pstRtspInfo->pu8RtspUserName);
		list_del(&pstRtspInfo->list);
		free(pstRtspInfo);
	}

	return 0;
}

int ST_RtspParameterSet(RTSP_Info_t *pstRtspInfo, MI_S8 *ps8String)
{
	MI_S8 *ps8Arg = NULL;
    MI_U8 u8ChnNum = 0;

	//ChnStart
	ps8Arg = strtok(ps8String, " ");
    pstRtspInfo->u8ChnStart = atoi(ps8Arg);
    //printf("u8ChnStart = %d\n", pstRtspInfo->u8ChnStart);

    //ChnEnd
    ps8Arg = strtok(NULL, " ");
    pstRtspInfo->u8ChnEnd = atoi(ps8Arg);
    //printf("u8chnEnd = %d\n", pstRtspInfo->u8ChnEnd);

	//Width
	ps8Arg = strtok(NULL, " ");
	pstRtspInfo->u32PixelWidth = atoi(ps8Arg);
    //printf("Width = %d\n", pstRtspInfo->u32PixelWidth);

	//Height
	ps8Arg = strtok(NULL, " ");
	pstRtspInfo->u32PixelHeight = atoi(ps8Arg);
    //printf("Height = %d\n", pstRtspInfo->u32PixelHeight);

	//FrameRate
	ps8Arg = strtok(NULL, " ");
	pstRtspInfo->u32FrameRate = atoi(ps8Arg);
    //printf("FrameRate = %d\n", pstRtspInfo->u32FrameRate);

	//Type
	ps8Arg = strtok(NULL, " ");
	ST_RtspTypeSet(pstRtspInfo, ps8Arg);
    //printf("Type = %d\n", pstRtspInfo->eVdecType);

	//Path
	ps8Arg = strtok(NULL, " ");
	pstRtspInfo->pu8RtspPath = malloc(strlen(ps8Arg) + 1);
	memcpy(pstRtspInfo->pu8RtspPath, ps8Arg, strlen(ps8Arg));
	pstRtspInfo->pu8RtspPath[strlen(ps8Arg)] = '\0';

	//UserName
	ps8Arg = strtok(NULL, " ");
	pstRtspInfo->pu8RtspUserName = malloc(strlen(ps8Arg) + 1);
	memcpy(pstRtspInfo->pu8RtspUserName, ps8Arg, strlen(ps8Arg));
	pstRtspInfo->pu8RtspUserName[strlen(ps8Arg)] = '\0';

	//Passwd
	ps8Arg = strtok(NULL, " ");
    //printf("strlen = %d\n", strlen(ps8Arg));
	pstRtspInfo->pu8RtspPasswd = malloc(strlen(ps8Arg) + 1);
	memcpy(pstRtspInfo->pu8RtspPasswd, ps8Arg, strlen(ps8Arg));

    //In windows, the last line will have "\n"
    if ('\n' == pstRtspInfo->pu8RtspPasswd[strlen(ps8Arg) - 1])
    {
        pstRtspInfo->pu8RtspPasswd[strlen(ps8Arg) - 1] = '\0';
    }
    else
    {
	    pstRtspInfo->pu8RtspPasswd[strlen(ps8Arg)] = '\0';
    }

    pstRtspInfo->bInit = FALSE;

    for (u8ChnNum = pstRtspInfo->u8ChnStart; u8ChnNum <= pstRtspInfo->u8ChnEnd; u8ChnNum++)
    {
        _gs32VoChnNum += 1;
    }

	return 0;
}

int ST_RtspTypeSet(RTSP_Info_t *pstRtspInfo, MI_S8 *ps8String)
{
    //printf("ps8String = %s\n", ps8String);
    //while(1);
	if (0 == strncmp("H264", ps8String, 4) || 0 == strncmp("h264", ps8String, 4))
	{
        //printf("h264\n");
		pstRtspInfo->eVdecType = E_MI_VDEC_CODEC_TYPE_H264;
	}
	else if (0 == strncmp("H265", ps8String, 4) || 0 == strncmp("h265", ps8String, 4))
	{
        //printf("h265\n");
		pstRtspInfo->eVdecType = E_MI_VDEC_CODEC_TYPE_H265;
	}
	else if (0 == strncmp("jpeg", ps8String, 4))
	{
		pstRtspInfo->eVdecType = E_MI_VDEC_CODEC_TYPE_JPEG;
	}
	else
	{
		printf("String Error:%s\n", ps8String);
		return -1;
	}

	return 0;
}

MI_U64 get_pts(MI_U32 u32FrameRate)
{
    if (0 == u32FrameRate)
    {
        return (MI_U64)(-1);
    }

    return (MI_U64)(1000 / u32FrameRate);
}

MI_S32 ST_GetFileParam(MI_S8 *pFileName)
{
    FILE *pFile = NULL;
    MI_U8 szString[256];
    MI_U32 u32Count = 0;

    pFile = fopen(pFileName, "r");
    if (NULL == pFile)
    {
        printf("fopen failed\n");
        return -1;
    }

    memset(szString, 0, 256);

    while(NULL != fgets(szString, 256, pFile))
    {
        RTSP_Info_t *pstRtspInfo = NULL;

        if (szString[0] == '/' || szString[0] == '#')
        {
            memset(szString, 0, 256);
            continue;
        }

        //skip blank line
        if (strlen(szString) < 10)
        {
            memset(szString, 0, 256);
            continue;
        }

        pstRtspInfo = (RTSP_Info_t* )malloc(sizeof(RTSP_Info_t));
        if (NULL == pstRtspInfo)
        {
            printf("malloc falied\n");
            return -1;
        }

        memset(pstRtspInfo, 0, sizeof(RTSP_Info_t));
        ST_RtspParameterSet(pstRtspInfo, szString);
        list_add_tail(&pstRtspInfo->list, &RTSP_List);

        memset(szString, 0, 256);
    }

    return MI_SUCCESS;
}

MI_S32 ST_GetInputParam(MI_S32 argc, char **argv)
{
    MI_U8 u8ChnNum = 0;
    MI_U32 u32i = 1;
    RTSP_Info_t *pstRtspInfo = NULL;

    while(u32i < argc)
    {

        pstRtspInfo = (RTSP_Info_t* )malloc(sizeof(RTSP_Info_t));
        if (NULL == pstRtspInfo)
        {
            printf("malloc falied\n");
            return -1;
        }

        memset(pstRtspInfo, 0, sizeof(RTSP_Info_t));

        //ChnStart
        pstRtspInfo->u8ChnStart = atoi(argv[u32i++]);

        //ChnEnd
        pstRtspInfo->u8ChnEnd = atoi(argv[u32i++]);

        //Width
        //printf("width = %s\n", argv[u32i]);
        pstRtspInfo->u32PixelWidth = atoi(argv[u32i++]);

        //Height
        //printf("height =  %s\n", argv[u32i]);
        pstRtspInfo->u32PixelHeight = atoi(argv[u32i++]);

        //FrameRate
        //printf("FrameRate = %s\n", argv[u32i]);
        pstRtspInfo->u32FrameRate = atoi(argv[u32i++]);

        //Type
        //printf("Type = %s\n", argv[u32i]);
        ST_RtspTypeSet(pstRtspInfo, argv[u32i++]);

        //Path
        //printf("path = %s\n", argv[u32i]);
        pstRtspInfo->pu8RtspPath = malloc(strlen(argv[u32i]) + 1);
        memcpy(pstRtspInfo->pu8RtspPath, argv[u32i], strlen(argv[u32i]));
        pstRtspInfo->pu8RtspPath[strlen(argv[u32i++])] = '\0';

        //UserName
        //printf("name = %s\n", argv[u32i]);
        pstRtspInfo->pu8RtspUserName = malloc(strlen(argv[u32i]) + 1);
        memcpy(pstRtspInfo->pu8RtspUserName, argv[u32i], strlen(argv[u32i]));
        pstRtspInfo->pu8RtspUserName[strlen(argv[u32i++])] = '\0';

        //Passwd
        //printf("passwd = %s\n", argv[u32i]);
        pstRtspInfo->pu8RtspPasswd = malloc(strlen(argv[u32i]) + 1);
        memcpy(pstRtspInfo->pu8RtspPasswd, argv[u32i], strlen(argv[u32i]));
        pstRtspInfo->pu8RtspPasswd[strlen(argv[u32i++])] = '\0';

        pstRtspInfo->bInit = FALSE;

       // getchar();
        //ST_RtspPrint(pstRtspInfo);
        //while(1);
        list_add_tail(&pstRtspInfo->list, &RTSP_List);

        for (u8ChnNum = pstRtspInfo->u8ChnStart; u8ChnNum <= pstRtspInfo->u8ChnEnd; u8ChnNum ++)
        {
            _gs32VoChnNum ++;
        }
    }


    return MI_SUCCESS;
}



void ST_GetSplitMode(void)
{
    if (1 == _gs32VoChnNum) //1window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_ONE;
        _stTestParam.s32TotalChnNum = 1;
    }
    else if ((2 == _gs32VoChnNum)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_TWO;
        _stTestParam.s32TotalChnNum = 2;
    }
    else if ((_gs32VoChnNum <= 4)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_FOUR;
        _stTestParam.s32TotalChnNum = 4;
    }
    else if ((_gs32VoChnNum <= 9)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_NINE;//9window
        _stTestParam.s32TotalChnNum = 9;
    }
    else if ((_gs32VoChnNum <= 16)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_SIXTEEN;//9window
        _stTestParam.s32TotalChnNum = 16;
    }
    else if ((_gs32VoChnNum <= 25)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_25;//9window
        _stTestParam.s32TotalChnNum = 25;
    }
    else if ((_gs32VoChnNum <= 36)) //4window
    {
        _stTestParam.eSplitMode = E_ST_SPLIT_MODE_36;//9window
        _stTestParam.s32TotalChnNum = 36;
    }

    //printf("_gs32VoChnNum = %d\n", _gs32VoChnNum);
}

void CallBackFunc(EN_RTSP_BACK_MSG msg, RTSP_STREAM_INFO * streamInfo, void* pUser, const char* pChId)
{
    static struct timeval tv;
    static struct timeval tv_tmp;
    double ms = 0.0;
    ST_TEM_USER_DATA stUserData;;
    MI_U8 szPthreadName[30];
    struct list_head *pstPos = NULL;
    RTSP_Info_t *pstRtspInfo = NULL;
    MI_U8 u8ChnNum = 0;
#if RTSP_WRITE_FILE
    MI_U32 u32Ret = 0;
#endif

    if(e_stream_data != msg)
    {
        return;
    }

    if (_gs32RtspBreak)
    {
        return ;
    }

    pthread_mutex_lock(&CallBackMutex);

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        if (0 == strncmp(pChId, pstRtspInfo->pu8RtspPath, strlen(pChId)))
        {
            for (u8ChnNum = pstRtspInfo->u8ChnStart; u8ChnNum <= pstRtspInfo->u8ChnEnd; u8ChnNum ++)
            {

                if (u8ChnNum > (_gs32VoChnNum -1 ))
                {
                    continue;
                }
#if RTSP_WRITE_FILE
                u32Ret = fwrite(streamInfo->pData, 1, streamInfo->length, _pFile[u8ChnNum]);
                if (u32Ret < streamInfo->length)
                {
                    printf("fwrite failed: _pFile[%d]\n", u8ChnNum);
                    sleep(1);
                }
#endif
                memset(szPthreadName, 0, 30);
                sprintf(szPthreadName, "pthread_%d", u8ChnNum);

                stUserData.pUserData = streamInfo;
                stUserData.u32UserDataSize = sizeof(RTSP_STREAM_INFO);
                //printf("send data\n");
                TemSend(szPthreadName, stUserData);
            }
        }
    }

    tv_tmp = tv;

    pthread_mutex_unlock(&CallBackMutex);
}

MI_S32 ST_RtspInit(void)
{
    struct list_head *pstPos = NULL;
    RTSP_Info_t *pstRtspInfo = NULL;
    int ret;

    ret = RTSP_Stream_Init(CallBackFunc);
    if(ret)
    {
        printf("RTSP_Stream_Init fail\n");
        return -1;
    }

    if (list_empty(&RTSP_List))
    {
        printf("list empty \n");
        return -1;
    }

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        if (FALSE == pstRtspInfo->bInit)
        {

            ret = RTSP_Open_Stream(pstRtspInfo->pu8RtspPath, "", "", NULL,0);
            if(ret)
            {
                printf("RTSP_Open_Stream fail\n");
                return -1;
            }

            pstRtspInfo->bInit = TRUE;
        }
    }

	return MI_SUCCESS;
}

void * Monitor(ST_TEM_BUFFER stBuffer, pthread_mutex_t *pMutex)
{
    return NULL;
}

void * Signal(ST_TEM_BUFFER stBuffer, ST_TEM_USER_DATA stUsrData, pthread_mutex_t *pMutex)
{
    MI_SYS_ChnPort_t *pstChnPort;
    RTSP_STREAM_INFO *pstStreamInfo;
    MI_S32 s32Ret = MI_SUCCESS;
	MI_S32 s32TimeOutMs = 20;
    MI_U64 u64Pts = 0;
    MI_U32  u32FrameRate = 0;
    MI_VDEC_CHN vdecChn = 0;
    MI_VDEC_VideoStream_t stVdecStream;
    MI_U32 u32CycleCount = 0;

    memset(&stVdecStream, 0, sizeof(MI_VDEC_VideoStream_t));
    //printf("signal come send stream to vdec\n");
    pstChnPort = (MI_SYS_ChnPort_t *)stBuffer.pTemBuffer;
    pstStreamInfo = (RTSP_STREAM_INFO *)stUsrData.pUserData;

    u32FrameRate = _stTestParam.stChannelInfo[pstChnPort->u32ChnId].u32SrcFrmRate;

    if (pstStreamInfo->length)
    {
        vdecChn = pstChnPort->u32ChnId;
        stVdecStream.pu8Addr      = pstStreamInfo->pData;
        stVdecStream.u32Len       = pstStreamInfo->length;
        stVdecStream.u64PTS       = u64Pts;
        stVdecStream.bEndOfFrame  = 1;
        stVdecStream.bEndOfStream = 0;

        while (MI_SUCCESS != (s32Ret = MI_VDEC_SendStream(vdecChn, &stVdecStream, s32TimeOutMs)))
        {
            // if frame is I frame and failed, need try more times
            if (1 == pstStreamInfo->keyFrame && u32CycleCount < MAX_CYCLE_COUNT)// I frame
            {
                u32CycleCount++;
                usleep(1000); // wait 2 ms
            }
            else
            {
                return NULL;
            }
        }
    }
    else
    {
        printf("Rtsp get data size is error\n");
    }

    u64Pts = u64Pts + get_pts(u32FrameRate);

    return NULL;
}


MI_S32 ST_StopPushDataRtsp(void)
{
    MI_S8 szPthreadName[30];
    struct list_head *pstPos = NULL;
    RTSP_Info_t *pstRtspInfo = NULL;
    MI_U8 u8ChnNum;

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        RTSP_Close_Stream(pstRtspInfo->pu8RtspPath);

        for (u8ChnNum = pstRtspInfo->u8ChnStart;  u8ChnNum <= pstRtspInfo->u8ChnEnd;  u8ChnNum++)
        {
            memset(szPthreadName, 0, 30);
            sprintf(szPthreadName, "pthread_%d",  u8ChnNum);
            TemStop(szPthreadName);
            TemClose(szPthreadName);
        }
    }

    RTSP_Stream_UnInit();

    return MI_SUCCESS;
}

void ST_SetLimit(void)
{
    struct rlimit limit;

    limit.rlim_cur = RLIM_INFINITY;
    limit.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CORE, &limit);
}


static MI_S32 UVC_EnableVenc(MI_VENC_ChnAttr_t *pstChnAttr)
{
    MI_U32 u32DevId = 0;
    MI_S32 s32Ret = 0;
    MI_SYS_ChnPort_t stChnPort;
    MI_VENC_ParamJpeg_t stJpegPara;
    //ASSERT(pstChnAttr);
    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    
    s32Ret = MI_VENC_CreateChn(0, pstChnAttr);
    if(pstChnAttr->stVeAttr.eType == E_MI_VENC_MODTYPE_JPEGE)
    {
        memset(&stJpegPara, 0, sizeof(MI_VENC_ParamJpeg_t));
        MI_VENC_GetJpegParam(0, &stJpegPara);
        stJpegPara.u32Qfactor = 60; //30;
        MI_VENC_SetJpegParam(0, &stJpegPara);
    }
    if (MI_SUCCESS != s32Ret)
    {
        printf("%s %d, MI_VENC_CreateChn %d error, %X\n", __func__, __LINE__, 0, s32Ret);
    }
    s32Ret = MI_VENC_GetChnDevid(0, &u32DevId);
    if (MI_SUCCESS != s32Ret)
    {
        printf("%s %d, MI_VENC_GetChnDevid %d error, %X\n", __func__, __LINE__, 0, s32Ret);
    }
    
    stChnPort.u32DevId = u32DevId;
    stChnPort.eModId = E_MI_MODULE_ID_VENC;
    stChnPort.u32ChnId = 0;
    stChnPort.u32PortId = 0;
    //This was set to (5, 10) and might be too big for kernel
    s32Ret = MI_SYS_SetChnOutputPortDepth(&stChnPort, 5, 5);
    if (MI_SUCCESS != s32Ret)
    {
        printf("%s %d, MI_SYS_SetChnOutputPortDepth %d error, %X\n", __func__, __LINE__, 0, s32Ret);
    }
    s32Ret = MI_VENC_StartRecvPic(0);
    if (MI_SUCCESS != s32Ret)
    {
        printf("%s %d, MI_VENC_StartRecvPic %d error, %X\n", __func__, __LINE__, 0, s32Ret);
    }

    return MI_SUCCESS;
}

int ST_SdkInit()
{
    MI_U8  u8ChnNum = 0;
    MI_U32 u32DevId = 0;
    struct list_head *pstPos = NULL;
    RTSP_Info_t *pstRtspInfo = NULL;

    MI_VDEC_ChnAttr_t stVdecChnAttr;
    MI_DIVP_ChnAttr_t stDivpChnAttr;
    MI_DIVP_OutputPortAttr_t stOutputPortAttr;

    ST_Sys_BindInfo_t stBindInfo;
    MI_SYS_ChnPort_t stChnPort;
    MI_VENC_ChnAttr_t stChnAttr;

    pthread_attr_t m_SigMonThreadAttr;
    ST_TEM_ATTR stAttr;
    size_t stacksize = 100;
    MI_U8 szPthreadName[30];

 
    
    STCHECKRESULT(ST_Sys_Init());

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        for (u8ChnNum = pstRtspInfo->u8ChnStart; u8ChnNum <= pstRtspInfo->u8ChnEnd; u8ChnNum++)
        {
            memset(&stVdecChnAttr,     0, sizeof(MI_VDEC_ChnAttr_t));
            memset(&stDivpChnAttr,     0, sizeof(MI_DIVP_ChnAttr_t));
            memset(&stOutputPortAttr,  0, sizeof(MI_DIVP_OutputPortAttr_t));
            memset(&stBindInfo,        0, sizeof(ST_Sys_BindInfo_t));
            memset(&stChnPort,         0, sizeof(MI_SYS_ChnPort_t));
            memset(&stChnAttr, 0, sizeof(MI_VENC_ChnAttr_t));

            /************************************************************************
                Module Init
             ************************************************************************/
            //Vdec Create Chn
            stVdecChnAttr.stVdecVideoAttr.u32RefFrameNum = 2;
            stVdecChnAttr.eVideoMode   = E_MI_VDEC_VIDEO_MODE_FRAME;
            stVdecChnAttr.u32BufSize   = 1024 * 1024 * 1;
            stVdecChnAttr.u32PicWidth  = pstRtspInfo->u32PixelWidth;
            stVdecChnAttr.u32PicHeight = pstRtspInfo->u32PixelHeight;
            stVdecChnAttr.u32Priority  = 0;
            stVdecChnAttr.eCodecType   = pstRtspInfo->eVdecType;
            
            ExecFunc(MI_VDEC_CreateChn(u8ChnNum, &stVdecChnAttr), MI_SUCCESS);
            ExecFunc(MI_VDEC_StartChn(u8ChnNum), MI_SUCCESS);
            
            //Divp Create Chn
            stDivpChnAttr.bHorMirror  = FALSE;
            stDivpChnAttr.bVerMirror  = FALSE;
            stDivpChnAttr.eDiType     = E_MI_DIVP_DI_TYPE_OFF;
            stDivpChnAttr.eRotateType = E_MI_SYS_ROTATE_NONE;
            stDivpChnAttr.eTnrLevel   = E_MI_DIVP_TNR_LEVEL_OFF;
            stDivpChnAttr.stCropRect.u16X      = 0;
            stDivpChnAttr.stCropRect.u16Y      = 0;
            stDivpChnAttr.stCropRect.u16Width  = pstRtspInfo->u32PixelWidth; //Vdec pic w
            stDivpChnAttr.stCropRect.u16Height = pstRtspInfo->u32PixelHeight; //Vdec pic h
            stDivpChnAttr.u32MaxWidth  = pstRtspInfo->u32PixelWidth; //max size picture can pass
            stDivpChnAttr.u32MaxHeight = pstRtspInfo->u32PixelHeight;
            STCHECKRESULT(MI_DIVP_CreateChn(u8ChnNum, &stDivpChnAttr));
            STCHECKRESULT(MI_DIVP_GetChnAttr(u8ChnNum, &stDivpChnAttr));
            STCHECKRESULT(MI_DIVP_SetChnAttr(u8ChnNum, &stDivpChnAttr));
            STCHECKRESULT(MI_DIVP_StartChn(u8ChnNum));

            memset(&stOutputPortAttr, 0, sizeof(stOutputPortAttr));
            stOutputPortAttr.eCompMode    = E_MI_SYS_COMPRESS_MODE_NONE;
            stOutputPortAttr.ePixelFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;//E_MI_SYS_PIXEL_FRAME_YUV422_YUYV;
            stOutputPortAttr.u32Width     = ALIGN_BACK(stVdecChnAttr.u32PicWidth, DISP_WIDTH_ALIGN);
            stOutputPortAttr.u32Height    = ALIGN_BACK(stVdecChnAttr.u32PicHeight, DISP_HEIGHT_ALIGN);
            STCHECKRESULT(MI_DIVP_SetOutputPortAttr(u8ChnNum, &stOutputPortAttr));
            //init warp
            MI_SYS_ChnPort_t stChnPort;
            MI_WARP_DEV dev;
            MI_WARP_CHN ch;
            dev = 0;
            ch = 0;
            STCHECKRESULT(ST_Warp_Init(dev,ch,E_WARP_1920_1080_NV12));
            /************************************************
            Step6:  init Warp
            *************************************************/
            memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
            stChnPort.eModId = E_MI_MODULE_ID_WARP;
            stChnPort.u32DevId = 0;
            stChnPort.u32ChnId = 0;
            stChnPort.u32PortId = 0;
            MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 4);
            STCHECKRESULT(ST_Warp_CreateChannel(ch)); //default support port2 --->>> venc

            MI_DISP_PubAttr_t stPubAttr;
            MI_DISP_VideoLayerAttr_t stLayerAttr;
            MI_DISP_InputPortAttr_t stInputPortAttr;

            //init disp
            memset(&stPubAttr, 0, sizeof(stPubAttr));
            stPubAttr.u32BgColor = YUYV_BLACK;
            stPubAttr.eIntfSync = E_MI_DISP_OUTPUT_1080P60;
            stPubAttr.eIntfType = E_MI_DISP_INTF_HDMI;
            ExecFunc(MI_DISP_SetPubAttr(0, &stPubAttr), MI_SUCCESS);
            ExecFunc(MI_DISP_Enable(0), MI_SUCCESS);

            memset(&stLayerAttr, 0, sizeof(stLayerAttr));
            stLayerAttr.stVidLayerSize.u16Width  = 1920;
            stLayerAttr.stVidLayerSize.u16Height = 1080;

            stLayerAttr.ePixFormat = E_MI_SYS_PIXEL_FRAME_YUV_MST_420;
            stLayerAttr.stVidLayerDispWin.u16X      = 0;
            stLayerAttr.stVidLayerDispWin.u16Y      = 0;
            stLayerAttr.stVidLayerDispWin.u16Width  = 1920;
            stLayerAttr.stVidLayerDispWin.u16Height = 1080;

            ExecFunc(MI_DISP_BindVideoLayer(0, 0), MI_SUCCESS);
            ExecFunc(MI_DISP_SetVideoLayerAttr(0, &stLayerAttr), MI_SUCCESS);
            ExecFunc(MI_DISP_GetVideoLayerAttr(0, &stLayerAttr), MI_SUCCESS);

            ExecFunc(MI_DISP_EnableVideoLayer(0), MI_SUCCESS);

            //init disp ch
            memset(&stInputPortAttr, 0, sizeof(stInputPortAttr));
            ExecFunc(MI_DISP_GetInputPortAttr(0, 0, &stInputPortAttr), MI_SUCCESS);
            stInputPortAttr.stDispWin.u16X      = 0;
            stInputPortAttr.stDispWin.u16Y      = 0;

            stInputPortAttr.stDispWin.u16Width  = 1920;
            stInputPortAttr.stDispWin.u16Height = 1080;
            
            ExecFunc(MI_DISP_SetInputPortAttr(0, 0, &stInputPortAttr), MI_SUCCESS);
            ExecFunc(MI_DISP_GetInputPortAttr(0, 0, &stInputPortAttr), MI_SUCCESS);
            ExecFunc(MI_DISP_EnableInputPort(0, 0), MI_SUCCESS);
            ExecFunc(MI_DISP_SetInputPortSyncMode(0, 0, E_MI_DISP_SYNC_MODE_FREE_RUN), MI_SUCCESS);

            //init HDMI
            STCHECKRESULT(ST_Hdmi_Init());
            STCHECKRESULT(ST_Hdmi_Start(E_MI_HDMI_ID_0, E_MI_HDMI_TIMING_1080_60P));
#if 0
            //Venc Create Chn
            stChnAttr.stVeAttr.eType = E_MI_VENC_MODTYPE_H265E;
            stChnAttr.stVeAttr.stAttrH265e.u32BFrameNum = 2; // not support B frame
            stChnAttr.stVeAttr.stAttrH265e.u32PicWidth = 1280;
            stChnAttr.stVeAttr.stAttrH265e.u32PicHeight = 720;
            stChnAttr.stVeAttr.stAttrH265e.u32MaxPicWidth = 1280;
            stChnAttr.stVeAttr.stAttrH265e.u32MaxPicHeight = 720;
            stChnAttr.stVeAttr.stAttrH265e.bByFrame = TRUE;
            stChnAttr.stRcAttr.eRcMode = E_MI_VENC_RC_MODE_H265VBR;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32SrcFrmRateNum= 30;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32SrcFrmRateDen = 1;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32Gop = 30;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32MaxBitRate=6*1024*1024;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32MaxQp=48;
            stChnAttr.stRcAttr.stAttrH265Vbr.u32MinQp=25;
            
            STCHECKRESULT(MI_VENC_CreateChn(u8ChnNum, &stChnAttr));

            STCHECKRESULT(MI_VENC_GetChnDevid(u8ChnNum, &u32DevId));
            
            stChnPort.u32DevId = u32DevId;
            stChnPort.eModId = E_MI_MODULE_ID_VENC;
            stChnPort.u32ChnId = u8ChnNum;
            stChnPort.u32PortId = 0;
            STCHECKRESULT(MI_SYS_SetChnOutputPortDepth(&stChnPort, 5, 5));

            STCHECKRESULT(MI_VENC_StartRecvPic(u8ChnNum));
#endif

            /************************************************************************
                Bind
             ************************************************************************/
            //Bind Vdec to Divp
            stBindInfo.stSrcChnPort.eModId    = E_MI_MODULE_ID_VDEC;
            stBindInfo.stSrcChnPort.u32DevId  = 0;
            stBindInfo.stSrcChnPort.u32ChnId  = u8ChnNum;
            stBindInfo.stSrcChnPort.u32PortId = 0;

            stBindInfo.stDstChnPort.eModId    = E_MI_MODULE_ID_DIVP;
            stBindInfo.stDstChnPort.u32DevId  = 0;
            stBindInfo.stDstChnPort.u32ChnId  = u8ChnNum; 
            stBindInfo.stDstChnPort.u32PortId = 0;
            stBindInfo.u32SrcFrmrate = 30;
            stBindInfo.u32DstFrmrate = 30;
            STCHECKRESULT(ST_Sys_Bind(&stBindInfo));

            //Bind Divp to Venc
            stBindInfo.stSrcChnPort.eModId    = E_MI_MODULE_ID_DIVP;
            stBindInfo.stSrcChnPort.u32DevId  = 0;
            stBindInfo.stSrcChnPort.u32ChnId  = u8ChnNum;
            stBindInfo.stSrcChnPort.u32PortId = 0;

            stBindInfo.stDstChnPort.eModId    = E_MI_MODULE_ID_WARP;
            stBindInfo.stDstChnPort.u32DevId  = u32DevId;
            stBindInfo.stDstChnPort.u32ChnId  = u8ChnNum; 
            stBindInfo.stDstChnPort.u32PortId = 0;
            stBindInfo.u32SrcFrmrate = 30;
            stBindInfo.u32DstFrmrate = 30;
            STCHECKRESULT(ST_Sys_Bind(&stBindInfo));
            
            //Bind Divp to Venc
            stBindInfo.stSrcChnPort.eModId    = E_MI_MODULE_ID_WARP;
            stBindInfo.stSrcChnPort.u32DevId  = 0;
            stBindInfo.stSrcChnPort.u32ChnId  = u8ChnNum;
            stBindInfo.stSrcChnPort.u32PortId = 0;

            stBindInfo.stDstChnPort.eModId    = E_MI_MODULE_ID_DISP;
            stBindInfo.stDstChnPort.u32DevId  = u32DevId;
            stBindInfo.stDstChnPort.u32ChnId  = u8ChnNum; 
            stBindInfo.stDstChnPort.u32PortId = 0;
            stBindInfo.u32SrcFrmrate = 30;
            stBindInfo.u32DstFrmrate = 30;
            STCHECKRESULT(ST_Sys_Bind(&stBindInfo));
#if 0
            //set venc output depth
            memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
            stChnPort.eModId    = E_MI_MODULE_ID_VENC;
            stChnPort.u32DevId  = u32DevId;
            stChnPort.u32ChnId  = u8ChnNum;
            stChnPort.u32PortId = 0;
            STCHECKRESULT(MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 7));
#endif
            /************************************************************************
                Create Tem
             ************************************************************************/
            stChnPort.eModId    = E_MI_MODULE_ID_VDEC;
            stChnPort.u32DevId  = 0;
            stChnPort.u32ChnId  = u8ChnNum;
            stChnPort.u32PortId = 0;

            
            //========================Tem Init==============================
            pthread_attr_getstacksize(&m_SigMonThreadAttr, &stacksize);
            pthread_attr_init(&m_SigMonThreadAttr);
            memset(&stAttr,     0, sizeof(ST_TEM_ATTR));

            stAttr.fpThreadDoSignal     = Signal; //send frame to vdec when signal arrived
            stAttr.fpThreadWaitTimeOut  = Monitor;
            stAttr.thread_attr          = m_SigMonThreadAttr;
            stAttr.u32ThreadTimeoutMs   = 1000;
            stAttr.bSignalResetTimer    = 0;
            stAttr.stTemBuf.pTemBuffer = &stChnPort;  //not use
            stAttr.stTemBuf.u32TemBufferSize = sizeof(MI_SYS_ChnPort_t); //not ues
            
            memset(szPthreadName, 0, 30);
            sprintf(szPthreadName, "pthread_%d", u8ChnNum);
            TemOpen(szPthreadName, stAttr);
            TemStartMonitor(szPthreadName);
        }
    }

    return 0;
}

int ST_ModuleExit(MI_S32 s32Channel)
{
    ST_Sys_BindInfo_t stBindInfo;

    //UnBind Vdec to Divp
    stBindInfo.stSrcChnPort.eModId = E_MI_MODULE_ID_VDEC;
    stBindInfo.stSrcChnPort.u32DevId = 0;
    stBindInfo.stSrcChnPort.u32ChnId = s32Channel;
    stBindInfo.stSrcChnPort.u32PortId = 0;

    stBindInfo.stDstChnPort.eModId = E_MI_MODULE_ID_DIVP;
    stBindInfo.stDstChnPort.u32DevId = 0;
    stBindInfo.stDstChnPort.u32ChnId = s32Channel;
    stBindInfo.stDstChnPort.u32PortId = 0;
    STCHECKRESULT(ST_Sys_UnBind(&stBindInfo));

    stBindInfo.stSrcChnPort.eModId = E_MI_MODULE_ID_DIVP;
    stBindInfo.stSrcChnPort.u32DevId = 0;
    stBindInfo.stSrcChnPort.u32ChnId = s32Channel;
    stBindInfo.stSrcChnPort.u32PortId = 0;

    stBindInfo.stDstChnPort.eModId = E_MI_MODULE_ID_VENC;
    STCHECKRESULT(MI_VENC_GetChnDevid(s32Channel, &stBindInfo.stDstChnPort.u32DevId));
    stBindInfo.stDstChnPort.u32DevId = 0;
    stBindInfo.stDstChnPort.u32ChnId = s32Channel;
    stBindInfo.stDstChnPort.u32PortId = 0;

    STCHECKRESULT(ST_Sys_UnBind(&stBindInfo)); 

    STCHECKRESULT(MI_VDEC_StopChn(s32Channel));
    STCHECKRESULT(MI_VDEC_DestroyChn(s32Channel));

    STCHECKRESULT(MI_DIVP_StopChn(s32Channel));
    STCHECKRESULT(MI_DIVP_DestroyChn(s32Channel));

    STCHECKRESULT(MI_VENC_StopRecvPic(s32Channel));
    STCHECKRESULT(MI_VENC_DestroyChn(s32Channel));

    return MI_SUCCESS;
}

int ST_SdkExit()
{
    MI_U8 u8ChnNum = 0;

    struct list_head *pstPos = NULL;
    RTSP_Info_t *pstRtspInfo = NULL;

    list_for_each(pstPos, &RTSP_List)
    {
        pstRtspInfo = list_entry(pstPos, RTSP_Info_t, list);

        for (u8ChnNum = pstRtspInfo->u8ChnStart; u8ChnNum <= pstRtspInfo->u8ChnEnd; u8ChnNum++)
        {
            STCHECKRESULT(ST_ModuleExit(u8ChnNum));
        }
    }

    STCHECKRESULT(ST_Sys_Exit());
}

static void *VENC0_Entry(void *args)
{
    printf("%s S\n", __FUNCTION__);
    Main_Context *pCtx = (Main_Context *)args;

    struct pollfd pfd = {0};
    char szFileName[64];
    MI_U32 u32WriteSize = 0;
    int write_len= 0;
    memset(szFileName, 0, sizeof(szFileName));
    sprintf(szFileName, "DumpVenc720_ch0.h265");

    int fd = open(szFileName, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (fd < 0) 
    {
        printf("%s open %d!\n", __FUNCTION__);
    }

            
    pfd.fd = 0;
    pfd.events = POLLIN | POLLERR;

    MI_SYS_ChnPort_t stChnPort = {0};
    stChnPort.eModId = E_MI_MODULE_ID_VENC;
    STCHECKRESULT(MI_VENC_GetChnDevid(0, &stChnPort.u32DevId));
    stChnPort.u32ChnId = 0;
    stChnPort.u32PortId = 0;
    MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 7);

    if (MI_SUCCESS != MI_SYS_GetFd(&stChnPort, (MI_S32 *)&pfd.fd)) {
        printf("%s MI_SYS_GetFd fail\n", __FUNCTION__);
        return 0;
    } else {

        while (pCtx->bResume)
        {
            int rval = poll(&pfd, 1, 200);
            if (rval < 0) {
                printf("%s poll error!\n", __FUNCTION__);
                break;
            } else if (rval == 0) {
                printf("%s get fd time out!\n", __FUNCTION__);
                continue;
            }

            MI_SYS_BUF_HANDLE hHandle;
            MI_SYS_BufInfo_t stBufInfo;

            MI_S32 s32Ret = MI_SYS_ChnOutputPortGetBuf(&stChnPort, &stBufInfo, &hHandle);
            if (s32Ret) {
                printf("%s MI_SYS_ChnOutputPortGetBuf %d!\n", __FUNCTION__, s32Ret);
                break;
            }

            u32WriteSize = stBufInfo.stRawData.u32ContentSize;
            write_len = write(fd, stBufInfo.stRawData.pVirAddr, u32WriteSize);
            //ASSERT(write_len == u32WriteSize);
            //printf("%s stFrameData addr: %p,size: %d\n", __FUNCTION__, stBufInfo.stRawData.pVirAddr, stBufInfo.stRawData.u32ContentSize);
            MI_SYS_ChnOutputPortPutBuf(hHandle);

        }
    }

    if (MI_SUCCESS != MI_SYS_CloseFd(pfd.fd))
    {
        printf("MI_SYS_CloseFd fail\n");
    }
    printf("%s E\n", __FUNCTION__);
    return 0;
}


static void *VENC1_Entry(void *args)
{
    printf("%s S\n", __FUNCTION__);
    Main_Context *pCtx = (Main_Context *)args;

    struct pollfd pfd = {0};
    char szFileName[64];
    MI_U32 u32WriteSize = 0;
    int write_len= 0;
    memset(szFileName, 0, sizeof(szFileName));
    sprintf(szFileName, "DumpVenc720_ch1.h265");

    int fd = open(szFileName, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (fd < 0) 
    {
        printf("%s open %d!\n", __FUNCTION__);
    }

            
    pfd.fd = 0;
    pfd.events = POLLIN | POLLERR;

    MI_SYS_ChnPort_t stChnPort = {0};
    stChnPort.eModId = E_MI_MODULE_ID_VENC;
    STCHECKRESULT(MI_VENC_GetChnDevid(1, &stChnPort.u32DevId));
    stChnPort.u32ChnId = 1;
    stChnPort.u32PortId = 0;
    MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 7);

    if (MI_SUCCESS != MI_SYS_GetFd(&stChnPort, (MI_S32 *)&pfd.fd)) {
        printf("%s MI_SYS_GetFd fail\n", __FUNCTION__);
        return 0;
    } else {

        while (pCtx->bResume)
        {
            int rval = poll(&pfd, 1, 200);
            if (rval < 0) {
                printf("%s poll error!\n", __FUNCTION__);
                break;
            } else if (rval == 0) {
                printf("%s get fd time out!\n", __FUNCTION__);
                continue;
            }

            MI_SYS_BUF_HANDLE hHandle;
            MI_SYS_BufInfo_t stBufInfo;

            MI_S32 s32Ret = MI_SYS_ChnOutputPortGetBuf(&stChnPort, &stBufInfo, &hHandle);
            if (s32Ret) {
                printf("%s MI_SYS_ChnOutputPortGetBuf %d!\n", __FUNCTION__, s32Ret);
                break;
            }

            u32WriteSize = stBufInfo.stRawData.u32ContentSize;
            write_len = write(fd, stBufInfo.stRawData.pVirAddr, u32WriteSize);
            //ASSERT(write_len == u32WriteSize);
            //printf("%s stFrameData addr: %p,size: %d\n", __FUNCTION__, stBufInfo.stRawData.pVirAddr, stBufInfo.stRawData.u32ContentSize);
            MI_SYS_ChnOutputPortPutBuf(hHandle);

        }
    }

    if (MI_SUCCESS != MI_SYS_CloseFd(pfd.fd))
    {
        printf("MI_SYS_CloseFd fail\n");
    }
    printf("%s E\n", __FUNCTION__);
    return 0;
}

static void *VDEC_Entry(void *args)
{
    printf("%s S\n", __FUNCTION__);
    Main_Context *pCtx = (Main_Context *)args;

    struct pollfd pfd = {0};
    char szFileName[64];
    MI_U32 u32WriteSize = 0;
    int write_len= 0;
    memset(szFileName, 0, sizeof(szFileName));
    sprintf(szFileName, "DumpVenc2560_1920.h264");

    int fd = open(szFileName, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if (fd < 0) 
    {
        printf("%s open %d!\n", __FUNCTION__);
    }

            
    pfd.fd = 0;
    pfd.events = POLLIN | POLLERR;

    MI_SYS_ChnPort_t stChnPort = {0};
    stChnPort.eModId = E_MI_MODULE_ID_VDEC;
    
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 0;
    stChnPort.u32PortId = 0;
    MI_SYS_SetChnOutputPortDepth(&stChnPort, 2, 7);

    if (MI_SUCCESS != MI_SYS_GetFd(&stChnPort, (MI_S32 *)&pfd.fd)) {
        printf("%s MI_SYS_GetFd fail\n", __FUNCTION__);
        return 0;
    } else {
        int frame_index = 0;
        while (pCtx->bResume)
        {
            frame_index++;

            int rval = poll(&pfd, 1, 200);
            if (rval < 0) {
                printf("%s poll error!\n", __FUNCTION__);
                break;
            } else if (rval == 0) {
                printf("%s get fd time out!\n", __FUNCTION__);
                continue;
            }

            MI_SYS_BUF_HANDLE hHandle;
            MI_SYS_BufInfo_t stBufInfo;

            MI_S32 s32Ret = MI_SYS_ChnOutputPortGetBuf(&stChnPort, &stBufInfo, &hHandle);
            if (s32Ret) {
                printf("%s MI_SYS_ChnOutputPortGetBuf %d!\n", __FUNCTION__, s32Ret);
                break;
            }

            u32WriteSize = stBufInfo.stRawData.u32ContentSize;
            //write_len = write(fd, stBufInfo.stRawData.pVirAddr, u32WriteSize);
            //ASSERT(write_len == u32WriteSize);
            //printf("%s stFrameData addr: %p,size: %d\n", __FUNCTION__, stBufInfo.stRawData.pVirAddr, stBufInfo.stRawData.u32ContentSize);
            MI_SYS_ChnOutputPortPutBuf(hHandle);

        }
    }

    if (MI_SUCCESS != MI_SYS_CloseFd(pfd.fd))
    {
        printf("MI_SYS_CloseFd fail\n");
    }
    printf("%s E\n", __FUNCTION__);
    return 0;
}

int ST_TCPConnect()
{
	char ip[20];
	int port;
	
	//char rebuf[100];
	struct sockaddr_in server;

	/*---------------------socket---------------------*/
	if((sockfd = socket(AF_INET,SOCK_STREAM,0))== -1){
		perror("socket error\n");
		exit(1);
	}

	/*---------------------connect--------------------*/
	
	sprintf(ip, "192.168.101.1");
	port = 8888;
	//sprintf(ip, "192.168.99.180");
	//port = 9999;

	bzero(&server,sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	inet_aton(ip,&server.sin_addr);
	if(connect(sockfd,(struct sockaddr *)&server,sizeof(server))== -1){
		perror("connect() error\n");
		exit(1);
	}
	else
	{
	    printf("connect succes!\n");
	}
	printf("#############TCP CONNECT###############\n");
    _gs32StartTrans = 1;
    return 0;
}

int ST_TransStart()
{
    char wrbuf[100];
    int revlen;
    if(_gs32StartTrans == 1)
    {
        memset(wrbuf, 0x00, 100);
        sprintf(wrbuf, "CMD_RTSP_TRANS_START");
        
        revlen = write(sockfd,wrbuf,strlen(wrbuf));
        if(revlen != strlen(wrbuf))
        {
            printf("trans start fail\n");
        }
        else
        {
            printf("trans start success\n");
        }
        printf("############# TRANS START ###############\n");
        _gs32StartTrans = 2;
    }
    
    return 0;
}



static void *Entry(void *args)
{
    Main_Context *pCtx = (Main_Context *)args;
    char wrbuf[100];
    int revlen;

    while (pCtx->bResume)
    {
        if(_gs32StartTrans == 2)
        {
            printf("CMD# ");
            memset(wrbuf, 0x00, 100);
            sprintf(wrbuf, "CMD_HEART");
            revlen = write(sockfd,wrbuf,strlen(wrbuf));
            if(revlen != strlen(wrbuf))
            {
                printf("heart send fail\n");
            }
            else
            {
                printf("heart send success\n");
            }
            sleep(5);
            
        }
    }

}

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        ST_INFO("Usage: %s <config-file>", argv[0]);
        ST_INFO("%s config.txt\n", argv[0]);
        return -1;
    }
    #if 0
    //connect to tcp
    ST_TCPConnect();
    //send tcp heart beat
    pthread_t ThreadID;
    Main_Context ctx = {0};
    Main_Context *pCtx = &ctx;
    pCtx->bResume = true;
    
    pthread_create(&ThreadID, NULL, Entry, pCtx);
    #endif
    
    // Set sys resource limit
    ST_SetLimit();//let me think


    ST_GetFileParam(argv[1]);

#if RTSP_WRITE_FILE
    ST_RtspCreateFile();
#endif

#if 1//(defined ST_DEBUG_INPUT_PARAM) && (ST_DEBUG_INPUT_PARAM == 1)
        ST_RtspPrintList();
        usleep(100);
#endif
    
    //sdk init
    STCHECKRESULT(ST_SdkInit());
#if 0
    //create thread to get venc ch0 stream
    pthread_t VENCThreadID0;
    Main_Context ctxVenc0 = {0};
    Main_Context *pCtxVenc0 = &ctxVenc0;
    pCtxVenc0->bResume = true;

    pthread_create(&VENCThreadID0, NULL, VENC0_Entry, pCtxVenc0);

    //create thread to get venc ch1 stream
    pthread_t VENCThreadID1;
    Main_Context ctxVenc1 = {0};
    Main_Context *pCtxVenc1 = &ctxVenc1;
    pCtxVenc1->bResume = true;
    
    pthread_create(&VENCThreadID1, NULL, VENC1_Entry, pCtxVenc1);
#endif
    
#if 0 //test vdec only
    pthread_t VDECThreadID;
    Main_Context ctx = {0};
    Main_Context *pCtx = &ctx;
    pCtx->bResume = true;
    
    pthread_create(&VDECThreadID, NULL, VDEC_Entry, pCtx);
#endif
    //tell rtsp server start trans
    ST_TransStart();
    
    pthread_mutex_init(&CallBackMutex, NULL); //init rtsp callback thread
    ST_RtspInit();

    char cmd = 0;
    while(1)
    {
        cmd = getchar();
        if (cmd == 'q')
            break;

    }

EXIT_1:

    printf("do exit \n");

    ST_StopPushDataRtsp();
    ST_SdkExit();

#if RTSP_WRITE_FILE
    ST_RtspCloseFile();
#endif
    ST_RtspRelease();

    pthread_mutex_destroy(&CallBackMutex);

    printf("exit done!\n");

    return 0;
}
