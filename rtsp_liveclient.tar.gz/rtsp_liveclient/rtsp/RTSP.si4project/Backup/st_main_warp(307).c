#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <signal.h>

#include <poll.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/resource.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>

#include<sys/time.h>
#include<unistd.h>

#include <assert.h>
#include <ctype.h>


#include <sys/socket.h>
#include <netinet/in.h>


#include "mi_sys.h"
#include "mi_vdec.h"
#include "mi_divp.h"
#include "mi_disp.h"

#include "mi_venc.h"
#include "mi_common.h"

#include "st_common.h"
#include "st_hdmi.h"
#include "st_warp.h"

#define DISP_XPOS_ALIGN     2
#define DISP_YPOS_ALIGN     2
#define DISP_WIDTH_ALIGN    2
#define DISP_HEIGHT_ALIGN   2

#define DST_FRAME 30
#define SRC_FRAME 30

#define DO_ONE_FRAME    0

typedef struct
{
    void *pInFrame;
    MI_S32 s32Size;
    
} InputData_t;


static void *WarpInputFunc0(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 0;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc1(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 1;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc2(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 2;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc3(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 3;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc4(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 4;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc5(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 5;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc6(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 6;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc7(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 7;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}

static void *WarpInputFunc8(void *args)
{   
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    MI_SYS_ChnPort_t stChnPort;
    time_t stTime = 0;
    
    InputData_t *pData = (InputData_t *)args;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 2560;
    stBufConf.stFrameCfg.u16Height = 1920;

    memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
    stChnPort.eModId = E_MI_MODULE_ID_WARP;
    stChnPort.u32DevId = 0;
    stChnPort.u32ChnId = 8;
    stChnPort.u32PortId = 0;

    while(1)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pData->pInFrame, pData->s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pData->pInFrame+pData->s32Size*2/3, pData->s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], pData->s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], pData->s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        usleep(30*1000);
    }
}


int main(int argc, const char *argv[])
{
    //init warp
    MI_SYS_ChnPort_t stChnPort;
    MI_WARP_DEV dev = 0;
    MI_WARP_CHN ch = 0;
    int i;
    
    ExecFunc(MI_WARP_CreateDevice(dev), MI_WARP_OK);
    ExecFunc(MI_WARP_StartDev(dev), MI_WARP_OK);
    
    for(i = 0;i < 1;i++)
    {
        STCHECKRESULT(ST_Warp_Init(dev,ch,E_WARP_640_480_NV12));
        /************************************************
        Step6:  init Warp
        *************************************************/
        memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
        stChnPort.eModId = E_MI_MODULE_ID_WARP;
        stChnPort.u32DevId = 0;
        stChnPort.u32ChnId = ch;
        stChnPort.u32PortId = 0;
        MI_SYS_SetChnOutputPortDepth(&stChnPort, 5, 7);
        STCHECKRESULT(ST_Warp_CreateChannel(ch)); //default support port2 --->>> venc

        MI_WARP_PortSize_t stPortInfo;
        stPortInfo.u16Width = 640;
        stPortInfo.u16Height = 480;
        MI_WARP_SetOutPortSize(dev, ch, stPortInfo);

        //Divp Create 
        MI_DIVP_ChnAttr_t stDivpChnAttr;
        MI_DIVP_OutputPortAttr_t stOutputPortAttr;
        
        stDivpChnAttr.bHorMirror  = FALSE;
        stDivpChnAttr.bVerMirror  = FALSE;
        stDivpChnAttr.eDiType     = E_MI_DIVP_DI_TYPE_OFF;
        stDivpChnAttr.eRotateType = E_MI_SYS_ROTATE_NONE;
        stDivpChnAttr.eTnrLevel   = E_MI_DIVP_TNR_LEVEL_OFF;
        stDivpChnAttr.stCropRect.u16X      = 0;
        stDivpChnAttr.stCropRect.u16Y      = 0;
        stDivpChnAttr.stCropRect.u16Width  = 640;//pstRtspInfo->u32PixelWidth; //Vdec pic w
        stDivpChnAttr.stCropRect.u16Height = 480;//pstRtspInfo->u32PixelHeight; //Vdec pic h
        stDivpChnAttr.u32MaxWidth  = 640;//pstRtspInfo->u32PixelWidth; //max size picture can pass
        stDivpChnAttr.u32MaxHeight = 480;//pstRtspInfo->u32PixelHeight;
        STCHECKRESULT(MI_DIVP_CreateChn(ch, &stDivpChnAttr));
        STCHECKRESULT(MI_DIVP_GetChnAttr(ch, &stDivpChnAttr));
        STCHECKRESULT(MI_DIVP_SetChnAttr(ch, &stDivpChnAttr));
        STCHECKRESULT(MI_DIVP_StartChn(ch));

        memset(&stOutputPortAttr, 0, sizeof(stOutputPortAttr));
        stOutputPortAttr.eCompMode    = E_MI_SYS_COMPRESS_MODE_NONE;
        stOutputPortAttr.ePixelFormat = E_MI_SYS_PIXEL_FRAME_YUV422_YUYV;//E_MI_SYS_PIXEL_FRAME_YUV422_YUYV;
        stOutputPortAttr.u32Width     = ALIGN_BACK(640, DISP_WIDTH_ALIGN);
        stOutputPortAttr.u32Height    = ALIGN_BACK(480, DISP_HEIGHT_ALIGN);
        STCHECKRESULT(MI_DIVP_SetOutputPortAttr(ch, &stOutputPortAttr));
        ch++;
    }
            

    //init disp
    MI_DISP_PubAttr_t stPubAttr;
    MI_DISP_VideoLayerAttr_t stLayerAttr;
    MI_DISP_InputPortAttr_t stInputPortAttr;
    
    memset(&stPubAttr, 0, sizeof(stPubAttr));
    stPubAttr.u32BgColor = YUYV_BLACK;
    stPubAttr.eIntfSync = E_MI_DISP_OUTPUT_1080P60;
    stPubAttr.eIntfType = E_MI_DISP_INTF_HDMI;
    ExecFunc(MI_DISP_SetPubAttr(0, &stPubAttr), MI_SUCCESS);
    ExecFunc(MI_DISP_Enable(0), MI_SUCCESS);

    memset(&stLayerAttr, 0, sizeof(stLayerAttr));
    stLayerAttr.stVidLayerSize.u16Width  = 1920;
    stLayerAttr.stVidLayerSize.u16Height = 1080;

    stLayerAttr.ePixFormat = E_MI_SYS_PIXEL_FRAME_YUV_MST_420;
    stLayerAttr.stVidLayerDispWin.u16X      = 0;
    stLayerAttr.stVidLayerDispWin.u16Y      = 0;
    stLayerAttr.stVidLayerDispWin.u16Width  = 1920;
    stLayerAttr.stVidLayerDispWin.u16Height = 1080;

    ExecFunc(MI_DISP_BindVideoLayer(0, 0), MI_SUCCESS);
    ExecFunc(MI_DISP_SetVideoLayerAttr(0, &stLayerAttr), MI_SUCCESS);
    ExecFunc(MI_DISP_GetVideoLayerAttr(0, &stLayerAttr), MI_SUCCESS);

    ExecFunc(MI_DISP_EnableVideoLayer(0), MI_SUCCESS);

    //init disp ch
    for(i = 0; i < 1; i++)
    {
        memset(&stInputPortAttr, 0, sizeof(stInputPortAttr));
        ExecFunc(MI_DISP_GetInputPortAttr(0, i, &stInputPortAttr), MI_SUCCESS);
        stInputPortAttr.stDispWin.u16X      = (i%3)*640;
        stInputPortAttr.stDispWin.u16Y      = (i/3)*480;

        stInputPortAttr.stDispWin.u16Width  = 640;
        stInputPortAttr.stDispWin.u16Height = 480;
        
        ExecFunc(MI_DISP_SetInputPortAttr(0, i, &stInputPortAttr), MI_SUCCESS);
        ExecFunc(MI_DISP_GetInputPortAttr(0, i, &stInputPortAttr), MI_SUCCESS);
        ExecFunc(MI_DISP_EnableInputPort(0, i), MI_SUCCESS);
        ExecFunc(MI_DISP_SetInputPortSyncMode(0, i, E_MI_DISP_SYNC_MODE_FREE_RUN), MI_SUCCESS);
    }

    //init HDMI
    STCHECKRESULT(ST_Hdmi_Init());
    STCHECKRESULT(ST_Hdmi_Start(E_MI_HDMI_ID_0, E_MI_HDMI_TIMING_1080_60P));

    ST_Sys_BindInfo_t stBindInfo;
    for(i = 0; i < 1; i++)
    {
        //Bind warp to Divp
        memset(&stBindInfo,        0, sizeof(ST_Sys_BindInfo_t));
        stBindInfo.stSrcChnPort.eModId    = E_MI_MODULE_ID_WARP;
        stBindInfo.stSrcChnPort.u32DevId  = 0;
        stBindInfo.stSrcChnPort.u32ChnId  = i;
        stBindInfo.stSrcChnPort.u32PortId = 0;

        stBindInfo.stDstChnPort.eModId    = E_MI_MODULE_ID_DIVP;
        stBindInfo.stDstChnPort.u32DevId  = 0;
        stBindInfo.stDstChnPort.u32ChnId  = i; 
        stBindInfo.stDstChnPort.u32PortId = 0;
        stBindInfo.u32SrcFrmrate = 30;
        stBindInfo.u32DstFrmrate = 30;
        STCHECKRESULT(ST_Sys_Bind(&stBindInfo));

        //Bind DIVP to DISP
        memset(&stBindInfo,        0, sizeof(ST_Sys_BindInfo_t));
        stBindInfo.stSrcChnPort.eModId    = E_MI_MODULE_ID_DIVP;
        stBindInfo.stSrcChnPort.u32DevId  = 0;
        stBindInfo.stSrcChnPort.u32ChnId  = i;
        stBindInfo.stSrcChnPort.u32PortId = 0;

        stBindInfo.stDstChnPort.eModId    = E_MI_MODULE_ID_DISP;
        stBindInfo.stDstChnPort.u32DevId  = 0;
        stBindInfo.stDstChnPort.u32ChnId  = 0; 
        stBindInfo.stDstChnPort.u32PortId = i;
        stBindInfo.u32SrcFrmrate = 30;
        stBindInfo.u32DstFrmrate = 30;
        STCHECKRESULT(ST_Sys_Bind(&stBindInfo));
    }
    
    MI_SYS_BufConf_t stBufConf;
    MI_SYS_BufInfo_t stBufInfo;
    MI_SYS_BUF_HANDLE hHandle;
    time_t stTime = 0;
    
    stBufConf.eBufType = E_MI_SYS_BUFDATA_FRAME;
    stBufConf.u32Flags = 0;
    stBufConf.u64TargetPts = time(&stTime);
    stBufConf.stFrameCfg.eFormat = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
    stBufConf.stFrameCfg.eFrameScanMode = E_MI_SYS_FRAME_SCAN_MODE_PROGRESSIVE;
    stBufConf.stFrameCfg.u16Width = 640;
    stBufConf.stFrameCfg.u16Height = 480;

    char szSrcFilePath[256];
    MI_S32 s32Size = 0;
    FILE *pSrcFile = NULL;
    void *pInFrame = NULL;
    
    memset(szSrcFilePath, 0, sizeof(szSrcFilePath));
    
    sprintf(szSrcFilePath, "%s", argv[1]);

    pSrcFile = fopen(szSrcFilePath, "r");
    if (!pSrcFile)
    {
        printf("open srcFile %s failed\n", szSrcFilePath);
        return 0;
    }

    fseek(pSrcFile, 0, SEEK_END);
    s32Size = ftell(pSrcFile);
    printf("file size is %d\n", s32Size);

    fseek(pSrcFile, 0, SEEK_SET);
    pInFrame = malloc(s32Size);
    memset(pInFrame, 0, s32Size);
    fread(pInFrame, 1, s32Size, pSrcFile);
#if 0
    InputData_t inputData;
    inputData.pInFrame = pInFrame;
    inputData.s32Size = s32Size;

    pthread_t WarpThreadID0;
    pthread_create(&WarpThreadID0, NULL, WarpInputFunc0, &inputData);

    pthread_t WarpThreadID1;
    pthread_create(&WarpThreadID1, NULL, WarpInputFunc1, &inputData);

    pthread_t WarpThreadID2;
    pthread_create(&WarpThreadID2, NULL, WarpInputFunc2, &inputData);

    pthread_t WarpThreadID3;
    pthread_create(&WarpThreadID3, NULL, WarpInputFunc3, &inputData);

    pthread_t WarpThreadID4;
    pthread_create(&WarpThreadID4, NULL, WarpInputFunc4, &inputData);

    pthread_t WarpThreadID5;
    pthread_create(&WarpThreadID5, NULL, WarpInputFunc5, &inputData);

    pthread_t WarpThreadID6;
    pthread_create(&WarpThreadID6, NULL, WarpInputFunc6, &inputData);

    pthread_t WarpThreadID7;
    pthread_create(&WarpThreadID7, NULL, WarpInputFunc7, &inputData);

    pthread_t WarpThreadID8;
    pthread_create(&WarpThreadID8, NULL, WarpInputFunc8, &inputData);
    
    while(1)
    {
        char cmd = getchar();
        if (cmd == 'q')
        {
             break;
        }

        
    }
#endif
    if(DO_ONE_FRAME)
    {
        // inject inFrame
        if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
        {
            printf("get input port buf fail\n");
            return 0;
        }

        memcpy(stBufInfo.stFrameData.pVirAddr[0], pInFrame, s32Size*2/3);
        memcpy(stBufInfo.stFrameData.pVirAddr[1], pInFrame+s32Size*2/3, s32Size/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], s32Size*2/3);
        MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], s32Size/3);
        MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

        while(1)
        {
            usleep(30*1000);
        }
    }
    else
    {
        while(1)
        {
            for(i = 0; i < 1; i++)
            {
                memset(&stChnPort, 0x0, sizeof(MI_SYS_ChnPort_t));
                stChnPort.eModId = E_MI_MODULE_ID_WARP;
                stChnPort.u32DevId = 0;
                stChnPort.u32ChnId = i;
                stChnPort.u32PortId = 0;
                // inject inFrame

                memset(&stBufInfo,0,sizeof(MI_SYS_BufInfo_t));
                if(MI_SUCCESS!=MI_SYS_ChnInputPortGetBuf(&stChnPort, &stBufConf, &stBufInfo, &hHandle, 100))
                {
                    printf("get input port buf fail\n");
                    break;
                }
                
                fseek(pSrcFile, 0, SEEK_SET);
                fread(stBufInfo.stFrameData.pVirAddr[0], 1, s32Size*2/3, pSrcFile);
                fseek(pSrcFile, s32Size*2/3, SEEK_SET);
                fread(stBufInfo.stFrameData.pVirAddr[1], 1, s32Size/3, pSrcFile);

                
                //memcpy(stBufInfo.stFrameData.pVirAddr[0], pInFrame, s32Size*2/3);
                //memcpy(stBufInfo.stFrameData.pVirAddr[1], pInFrame+s32Size*2/3, s32Size/3);
                MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[0], s32Size*2/3);
                MI_SYS_FlushInvCache(stBufInfo.stFrameData.pVirAddr[1], s32Size/3);
                MI_SYS_ChnInputPortPutBuf(hHandle, &stBufInfo, FALSE);

                usleep(1000*1000);
            }

            
        }
    }

            
    return 0;
}

