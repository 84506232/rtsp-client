#include <stdio.h>

#include "mi_sys.h"
#include "mi_divp.h"
#include "mi_divp_datatype.h"


#include "st_common.h"


#define DEFAULT_MAX_PICW 1920
#define DEFAULT_MAX_PICH 1080

MI_S32 ST_Sys_Init(void)
{
    MI_SYS_Version_t stVersion;
    MI_U64 u64Pts = 0;
    STCHECKRESULT(MI_SYS_Init()); //Sys Init
    memset(&stVersion, 0x0, sizeof(MI_SYS_Version_t));
    STCHECKRESULT(MI_SYS_GetVersion(&stVersion));
    ST_INFO("(%d) u8Version:0x%llx\n", __LINE__, stVersion.u8Version);
    STCHECKRESULT(MI_SYS_GetCurPts(&u64Pts));
    ST_INFO("(%d) u64Pts:0x%llx\n", __LINE__, u64Pts);

    u64Pts = 0xF1237890F1237890;
    STCHECKRESULT(MI_SYS_InitPtsBase(u64Pts));

    u64Pts = 0xE1237890E1237890;
    STCHECKRESULT(MI_SYS_SyncPts(u64Pts));

    return MI_SUCCESS;
}

MI_S32 ST_Sys_Exit(void)
{
    STCHECKRESULT(MI_SYS_Exit());

    return MI_SUCCESS;
}

MI_S32 ST_Sys_Bind(ST_Sys_BindInfo_t *pstBindInfo)
{
    ExecFunc(MI_SYS_BindChnPort(&pstBindInfo->stSrcChnPort, &pstBindInfo->stDstChnPort, \
        pstBindInfo->u32SrcFrmrate, pstBindInfo->u32DstFrmrate), MI_SUCCESS);

    return MI_SUCCESS;
}

MI_S32 ST_Sys_UnBind(ST_Sys_BindInfo_t *pstBindInfo)
{
    ExecFunc(MI_SYS_UnBindChnPort(&pstBindInfo->stSrcChnPort, &pstBindInfo->stDstChnPort), MI_SUCCESS);

    return MI_SUCCESS;
}

MI_U64 ST_Sys_GetPts(MI_U32 u32FrameRate)
{
    if (0 == u32FrameRate)
    {
        return (MI_U64)(-1);
    }

    return (MI_U64)(1000 / u32FrameRate);
}

MI_S32 ST_Get_VoRectBySplitMode(MI_S32 s32SplitMode, MI_S32 s32VoChnIndex, MI_U16 u16LayerW, MI_U16 u16LayerH, ST_Rect_t *pstRect)
{
    MI_U16 u16LayerWidth = u16LayerW;
    MI_U16 u16LayerHeight = u16LayerH;
    MI_S32 s32DivW = 0, s32DivH = 0;
    MI_U16 u16VoWidth = 0, u16VoHeight = 0;
    MI_S32 s32SupportChnNum = 0;

    switch (s32SplitMode)
    {
        case E_ST_SPLIT_MODE_ONE:
        {
            s32DivW = 1;
            s32DivH = 1;
            s32SupportChnNum = 1;
            if (0 != s32VoChnIndex)
            {
                ST_ERR("s32VoChnIndex err(%d)!!!\n", s32VoChnIndex);
                return -1;
            }
            else
            {
                pstRect->s32X = 0;
                pstRect->s32Y = 0;
                pstRect->u16PicW = u16LayerWidth;
                pstRect->u16PicH = u16LayerHeight;
            }
            break;
        }
        case E_ST_SPLIT_MODE_TWO:
        {
            s32DivW = 2;
            s32DivH = 1;
            s32SupportChnNum = 2;
            u16VoWidth = u16LayerWidth / 2;//align
            u16VoHeight = u16LayerHeight ;
            if (0 == s32VoChnIndex)
            {
                pstRect->s32X = 0;
                pstRect->s32Y = 0;
                pstRect->u16PicW = u16VoWidth;//u16LayerWidth;
                pstRect->u16PicH = u16VoHeight;//u16LayerHeight;
            }
            else if (1 == s32VoChnIndex)
            {
                pstRect->s32X = u16VoWidth;
                pstRect->s32Y = 0;
                pstRect->u16PicW = u16VoWidth;
                pstRect->u16PicH = u16VoHeight;
            }
            else
            {
                ST_ERR("s32VoChnIndex err(%d)!!!\n", s32VoChnIndex);
                return -1;
            }

            break;
        }
        case E_ST_SPLIT_MODE_FOUR:
        {
            s32DivW = 2;
            s32DivH = 2;
            s32SupportChnNum = 4;
            u16VoWidth = u16LayerWidth / 2;//align
            u16VoHeight = u16LayerHeight / 2;
            if ((s32VoChnIndex < s32SupportChnNum) && (s32VoChnIndex >=0))
            {
                pstRect->s32X = (s32VoChnIndex % s32DivW) * u16VoWidth;
                pstRect->s32Y = (s32VoChnIndex / s32DivW) * u16VoHeight;
                pstRect->u16PicW = u16VoWidth;
                pstRect->u16PicH = u16VoHeight;
            }
            else
            {
                ST_ERR("s32VoChnIndex err(%d)!!!\n", s32VoChnIndex);
                return -1;
            }
            break;
        }
        case E_ST_SPLIT_MODE_NINE:
        {
            s32DivW = 3;
            s32DivH = 3;
            s32SupportChnNum = 9;
            u16VoWidth = u16LayerWidth / 3;//align
            u16VoHeight = u16LayerHeight / 3;
            if ((s32VoChnIndex < s32SupportChnNum) && (s32VoChnIndex >=0))
            {
                pstRect->s32X = (s32VoChnIndex % s32DivW) * u16VoWidth;
                pstRect->s32Y = (s32VoChnIndex / s32DivW) * u16VoHeight;
                pstRect->u16PicW = u16VoWidth;
                pstRect->u16PicH = u16VoHeight;
            }
            else
            {
                ST_ERR("s32VoChnIndex err(%d)!!!\n", s32VoChnIndex);
                return -1;
            }
            break;
        }
        case E_ST_SPLIT_MODE_NINE_EX: //1 big win + 5 litte win
        {
            s32DivW = 3;
            s32DivH = 3;
            s32SupportChnNum = 6;
            u16VoWidth = u16LayerWidth / 3;//align
            u16VoHeight = u16LayerHeight / 3;
            break;
        }
        default:
            ST_ERR("Unsupported split mode(%d)!!!\n", s32SplitMode);
            return -1;
    }

    return MI_SUCCESS;
}

