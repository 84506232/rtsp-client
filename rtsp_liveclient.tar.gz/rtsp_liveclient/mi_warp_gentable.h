#ifndef _MI_WARP_H
#define _MI_WARP_H

#ifdef __cplusplus
extern "C" {
#endif

#define MI_WARP_MAX_PATH (512) /* max. length of full pathname */
#define MI_WARP_MAX_LINE_LEN (512) //for file parse

typedef void* WARP_DEV_HANDLE;
typedef void* WARP_DIS_BIN_HANDLE;
typedef void* WARP_BB_BIN_HANDLE;
//=================================================================================
typedef enum _mi_WARP_err
{
    MI_WARP_ERR_NONE = 0x200,
    MI_WARP_ERR_NOT_INIT,
    MI_WARP_ERR_NOT_INIT_LUT,
    MI_WARP_ERR_NOT_INIT_WORLD2CAM,
    MI_WARP_ERR_NOT_INIT_OUT,
    MI_WARP_ERR_INVALID_PARAMETER_WARP,
    MI_WARP_ERR_INVALID_PARAMETER_DONUT,
    MI_WARP_ERR_INVALID_PARAMETER_ERP,
    MI_WARP_ERR_INVALID_PARAMETER_MAP_DOWNSAMPLE,
    MI_WARP_ERR_OUT_OF_MEMORY,
    MI_WARP_ERR_OUT_OF_MEMORY_BIN,
    MI_WARP_ERR_IC_CHECK,
    MI_WARP_ERR_PARSE_LINE_BUFFER,
    MI_WARP_ERR_PARSE_FILE_READ,
    MI_WARP_ERR_PARSE_WARP_MODE,
    MI_WARP_ERR_PARSE_IMAGE_SIZE,
    MI_WARP_ERR_PARSE_IMAGE_CENTER,
    MI_WARP_ERR_PARSE_GRIDE_SIZE,
    MI_WARP_ERR_PARSE_PAN_LIMIT,
    MI_WARP_ERR_PARSE_TILT_LIMIT,
    MI_WARP_ERR_PARSE_ZOOM_LIMIT,
    MI_WARP_ERR_PARSE_ROTATE_LIMIT,
    MI_WARP_ERR_PARSE_RADIUS_LIMIT,
    MI_WARP_ERR_PARSE_FILE_IN_NONE,
    MI_WARP_ERR_MEM_ALLOCATE_FAIL,
    MI_WARP_ERR_MEM_FREE_FAIL,
    MI_WARP_ERR_WARP_SPLIT_ITERATIVE_FIND,
    MI_WARP_ERR_WARP_BIN_OUT_WRITE,
    MI_WARP_ERR_PARSE_DECIMATION_FACTOR,
    MI_WARP_ERR_PARSE_COEFFICIENTS,
    MI_WARP_ERR_PARSE_DISPLACEMENT_FORMAT,
    MI_WARP_ERR_PARSE_ADDRESS_MODE,
    MI_WARP_ERR_PARSE_FILE_TYPE,
    MI_WARP_ERR_PARSE_FILL_VALUES
}mi_WARP_err;
//=================================================================================
typedef enum _mi_WARP_path
{
    WARP_PATH_IN_FOLDER,
    WARP_PATH_OUT_FOLDER,
    WARP_PATH_WARP_BIN,
    WARP_PATH_SRC_IMAGE, //file name for source image
    WARP_PATH_NUM
}mi_WARP_path;
//=================================================================================
typedef enum _mi_WARP_table
{
    WARP_IN_TABLE,
    WARP_TABLE_NUM
}mi_WARP_table;
//=================================================================================
typedef enum _mi_WARP_MODE
{
    WARP_MODE_4R_CM,     //4 WARP views with ceiling mount mode
    WARP_MODE_4R_WM,     //4 WARP views with wall mount mode
    WARP_MODE_1R,        //1 undistorted view with ceiling/desk mount mode
    WARP_MODE_2P_CM,     //2 panorama views with ceiling mount mode
    WARP_MODE_1P_CM,     //1 panorama view with ceiling mount mode
    WARP_MODE_1P_WM,     //1 panorama views with wall mount mode
    WARP_MODE_1O,        //bypass mode
    WARP_MODE_1R_WM,     //1 undistorted view with ceiling/desk mount mode
    WARP_MODE_2P_DM      //2 panorama views with desk mount mode
}mi_WARP_MODE;
//=================================================================================
//config parse
typedef struct _mi_WARP_config_param
{
    char path_name[WARP_PATH_NUM][MI_WARP_MAX_PATH];   //-i, -o, -b
    int path_name_len[WARP_PATH_NUM];
    mi_WARP_MODE WARP_mode;   //-m, (0)4R_CM, (1)4R_WM, (2)1R, (3)2p, (4)1P_CM, (5)1P_WM, (6)1O, (7)1R_WM, (8)2P_DM
    int in_width;   //-s
    int in_height;
    int out_width;
    int out_height;
    int out_width_tile;
    int out_height_tile;
    int in_xc;      //-c
    int in_yc;
    int in_fisheye_radius;
    int grid_size;  //-d
    int pan_min;    //-p
    int pan_max;
    int tilt_min;   //-t
    int tilt_max;
    int zoom_min;   //-z
    int zoom_max;
    int rotate_min; //-r
    int rotate_max;
    int radius_min; //-a
    int radius_max;
    char table_name[WARP_TABLE_NUM][MI_WARP_MAX_PATH];   //-i, -o, -b
    int table_name_len[WARP_TABLE_NUM];
    int out_width_tile_stride;
    float coef_mat_fl[9];
    int addressing_mode;
    int relative_offset;
    int decimation_factor;
    int fill_val;
    int fill_val_chroma;
    int file_type;
}mi_WARP_config_param;
//=================================================================================
//parameters
typedef struct _mi_WARP_para
{
    mi_WARP_config_param* ptconfig_para;
    int view_index;
    int pan;
    int tilt;
    int rotate;
    float zoom;
    float zoom_h; //horizental zoom ratio, only for 1P WM mode
    float zoom_v; //vertical zoom ratio, only for 1P WM mode
    float pi;
    float fc;
    float fov;
    int out_rot;
    int r_inside;
    int r_outside;
    int theta_start;
    int theta_end;
}mi_WARP_para;
//=================================================================================
/*
 * mi_WARP_config_parse
 *   Parse configure file.
 *
 *
 * Parameters:
 *  in
 *   pfile_name: configure file path
 *  out
 *   tconfig_para : parsing result
 *
 * Return:
 *   mi_WARP_err error state
 */
mi_WARP_err mi_WARP_config_parse(char* pfile_name, mi_WARP_config_param* tconfig_para);
//=================================================================================
/*
 * mi_WARP_get_buffer_info
 *   Get working buffer length.
 *
 *
 * Parameters:
 *  in
 *   aptconfig_para: Configure setting which invlove image size and other paramters.
 *
 * Return:
 *   working buffer size
 */
int  mi_WARP_get_buffer_info(mi_WARP_config_param* aptconfig_para);
//=================================================================================
/*
* mi_WARP_buffer_free
*   free WARP binary buffer which be allocated by libWARP.a
*
*
* Parameters:
*  in
*   pWARP_dis_bin: binary buffer pointer of map file.
    pWARP_bb_bin binary buffer pointer of bb file.
*
* Return:
*   mi_WARP_err error state
*/
mi_WARP_err mi_WARP_buffer_free(WARP_DIS_BIN_HANDLE pWARP_dis_bin, WARP_BB_BIN_HANDLE pWARP_bb_bin);
//=================================================================================
/*
* mi_WARP_runtime_init
*   Generate bin file.
*
*
* Parameters:
*   in
*    pWorkingBuffer: working buffer
*    working_buf_len: working buffer size
*   out
*    aptWARP_para : WARP angle parameters
*
* Return:
*   WARP_DEV_HANDLE WARP handle pointer
*/
WARP_DEV_HANDLE mi_WARP_runtime_init(unsigned char* pWorkingBuffer, int working_buf_len, mi_WARP_para* aptWARP_para);
//=================================================================================
/*
* mi_warp_runtime_map_gen
*   Generate bin file of warp.
*
*
* Parameters:
*  in
*   aptWARP_handle: WARP handle be declare by mi_WARP_runtime_init()
*   aptmi_warp_para : warp parameters for user assign
*  out
*   pWARP_dis_bin: binary buffer pointer of map file.
    pWARP_bb_bin binary buffer pointer of bb file.
*
* Return:
*   mi_WARP_err error state
*/
mi_WARP_err mi_warp_runtime_map_gen(WARP_DEV_HANDLE aptWARP_handle, mi_WARP_para* aptmi_warp_para, WARP_DIS_BIN_HANDLE* pWARP_dis_bin, WARP_BB_BIN_HANDLE* pWARP_bb_bin);
//=================================================================================
#ifdef __cplusplus
}
#endif

#endif//#ifdef _MI_WARP_H
