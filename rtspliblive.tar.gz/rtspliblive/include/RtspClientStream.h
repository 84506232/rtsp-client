/***********************************************************************
** Copyright (C) mstar.
** Author       : andy.huang
** Date         : 2017-07-3
** Name         : RtspStreamClient.h
** Version      : 1.0
** Description  : RTSP���Ŀͻ��ˣ�ÿ��uri��ʹ��һ���ͻ������������ӡ�
** Modify Record:
1:
***********************************************************************/
// 
#ifndef _RTSP_CLIENT_STREAM_H_
#define _RTSP_CLIENT_STREAM_H_
// 
#include "liveMedia.hh"
#include "UsageEnvironment.hh"
#include "BasicUsageEnvironment.hh"
#include "RTSPClient.hh"
#include "RTPSink.hh"
#include "RTSP_Stream_API.h"
#include <string>

//#define DUMMY_SINK_RECEIVE_BUFFER_SIZE 1000000
using namespace std;


class NALBitstream
{
public:
	NALBitstream()
		: m_data(NULL), m_len(0), m_idx(0)
		, m_bits(0), m_byte(0), m_zeros(0)
	{
	}
	NALBitstream(void* data, int len)
	{
		Init(data, len);
	}
	void Init(void* data, int len)
	{
		m_data = (uint8_t*)data;
		m_len = len;
		m_idx = 0;
		m_bits = 0;
		m_byte = 0;
		m_zeros = 0;
	};
	uint8_t GetBYTE()
	{
		if (m_idx >= m_len)
			return 0;
		uint8_t b = m_data[m_idx++];
		if (b == 0)
		{
			m_zeros++;
			if ((m_idx < m_len) && (m_zeros == 2) && (m_data[m_idx] == 0x03))
			{
				m_idx++;
				m_zeros = 0;
			}
		}
		else  m_zeros = 0;

		return b;
	};

	uint32_t GetBit()
	{
		if (m_bits == 0)
		{
			m_byte = GetBYTE();
			m_bits = 8;
		}
		m_bits--;
		return (m_byte >> m_bits) & 0x1;
	};

	uint32_t GetWord(int bits)
	{
		uint32_t u = 0;
		while (bits > 0)
		{
			u <<= 1;
			u |= GetBit();
			bits--;
		}
		return u;
	};

	uint32_t GetUE()
	{
		int zeros = 0;
		while (m_idx < m_len && GetBit() == 0) zeros++;
		return GetWord(zeros) + ((1 << zeros) - 1);
	};

	int32_t GetSE()
	{
		uint32_t UE = GetUE();
		bool positive = UE & 1;
		int32_t SE = (UE + 1) >> 1;
		if (!positive)
		{
			SE = -SE;
		}
		return SE;
	};
private:
	uint8_t * m_data;
	int m_len;
	int m_idx;
	int m_bits;
	uint8_t m_byte;
	int m_zeros;
};

static const uint8_t default_scaling4[2][16] = {
	{ 6, 13, 20, 28, 13, 20, 28, 32,
	20, 28, 32, 37, 28, 32, 37, 42 },
{ 10, 14, 20, 24, 14, 20, 24, 27,
20, 24, 27, 30, 24, 27, 30, 34 }
};

static const uint8_t default_scaling8[2][64] = {
	{ 6, 10, 13, 16, 18, 23, 25, 27,
	10, 11, 16, 18, 23, 25, 27, 29,
	13, 16, 18, 23, 25, 27, 29, 31,
	16, 18, 23, 25, 27, 29, 31, 33,
	18, 23, 25, 27, 29, 31, 33, 36,
	23, 25, 27, 29, 31, 33, 36, 38,
	25, 27, 29, 31, 33, 36, 38, 40,
	27, 29, 31, 33, 36, 38, 40, 42 },
{ 9, 13, 15, 17, 19, 21, 22, 24,
13, 13, 17, 19, 21, 22, 24, 25,
15, 17, 19, 21, 22, 24, 25, 27,
17, 19, 21, 22, 24, 25, 27, 28,
19, 21, 22, 24, 25, 27, 28, 30,
21, 22, 24, 25, 27, 28, 30, 32,
22, 24, 25, 27, 28, 30, 32, 33,
24, 25, 27, 28, 30, 32, 33, 35 }
};

static const uint8_t zigzag_direct[64] = {
	0,   1,  8, 16,  9,  2,  3, 10,
	17, 24, 32, 25, 18, 11,  4,  5,
	12, 19, 26, 33, 40, 48, 41, 34,
	27, 20, 13,  6,  7, 14, 21, 28,
	35, 42, 49, 56, 57, 50, 43, 36,
	29, 22, 15, 23, 30, 37, 44, 51,
	58, 59, 52, 45, 38, 31, 39, 46,
	53, 60, 61, 54, 47, 55, 62, 63
};

static const uint8_t zigzag_scan[16 + 1] = {
	0 + 0 * 4, 1 + 0 * 4, 0 + 1 * 4, 0 + 2 * 4,
	1 + 1 * 4, 2 + 0 * 4, 3 + 0 * 4, 2 + 1 * 4,
	1 + 2 * 4, 0 + 3 * 4, 1 + 3 * 4, 2 + 2 * 4,
	3 + 1 * 4, 3 + 2 * 4, 2 + 3 * 4, 3 + 3 * 4,
};


static void decode_scaling_list(NALBitstream& bs, uint8_t *factors, int size, const uint8_t *jvt_list, const uint8_t *fallback_list)
{
	int i, last = 8, next = 8;
	const uint8_t *scan = size == 16 ? zigzag_scan : zigzag_direct;
	if (!bs.GetWord(1)) /* matrix not written, we use the predicted one */
		memcpy(factors, fallback_list, size * sizeof(uint8_t));
	else
	{
		for (i = 0; i < size; i++)
		{
			if (next)
				next = (last + bs.GetSE()) & 0xff;
			if (!i && !next) /* matrix not written, we use the preset one */
			{
				memcpy(factors, jvt_list, size * sizeof(uint8_t));
				break;
			}
			last = factors[scan[i]] = next ? next : last;
		}
	}
}

static int decode_scaling_matrices(NALBitstream &bs, int chroma_format_idc, uint8_t(*scaling_matrix4)[16], uint8_t(*scaling_matrix8)[64])
{
	const uint8_t *fallback[4] = {
		default_scaling4[0],
		default_scaling4[1],
		default_scaling8[0],
		default_scaling8[1]
	};
	int ret = 0;
	if (bs.GetWord(1))
	{
		ret = 1;
		decode_scaling_list(bs, scaling_matrix4[0], 16, default_scaling4[0], fallback[0]);        // Intra, Y
		decode_scaling_list(bs, scaling_matrix4[1], 16, default_scaling4[0], scaling_matrix4[0]); // Intra, Cr
		decode_scaling_list(bs, scaling_matrix4[2], 16, default_scaling4[0], scaling_matrix4[1]); // Intra, Cb
		decode_scaling_list(bs, scaling_matrix4[3], 16, default_scaling4[1], fallback[1]);        // Inter, Y
		decode_scaling_list(bs, scaling_matrix4[4], 16, default_scaling4[1], scaling_matrix4[3]); // Inter, Cr
		decode_scaling_list(bs, scaling_matrix4[5], 16, default_scaling4[1], scaling_matrix4[4]); // Inter, Cb
		decode_scaling_list(bs, scaling_matrix8[0], 64, default_scaling8[0], fallback[2]); // Intra, Y
		decode_scaling_list(bs, scaling_matrix8[3], 64, default_scaling8[1], fallback[3]); // Inter, Y
		if (chroma_format_idc == 3)
		{
			decode_scaling_list(bs, scaling_matrix8[1], 64, default_scaling8[0], scaling_matrix8[0]); // Intra, Cr
			decode_scaling_list(bs, scaling_matrix8[4], 64, default_scaling8[1], scaling_matrix8[3]); // Inter, Cr
			decode_scaling_list(bs, scaling_matrix8[2], 64, default_scaling8[0], scaling_matrix8[1]); // Intra, Cb
			decode_scaling_list(bs, scaling_matrix8[5], 64, default_scaling8[1], scaling_matrix8[4]); // Inter, Cb
		}
	}

	return ret;
}

// only 0x00 0x00 0x00 0x01 or 0x00 0x00 0x01 can pass
static bool ParseResolutionFromSps(uint8_t *pSps, uint16_t nLen, uint16_t &nWidth, uint16_t &nHeight, int nCodec = 0)
{
	if (pSps[2] == 0x01)
	{
		pSps += 3;
		nLen -= 3;
	}
	else if (pSps[3] == 0x01)
	{
		pSps += 4;
		nLen -= 4;
	}
	else
	{
		return false;
	}
	uint16_t nStartBit = 0;
	if (nCodec == 0) // 264
	{
		// Analyze SPS to find width and height
		NALBitstream bs(pSps, nLen);
		bs.GetWord(1); // forbidden_zero_bit
		bs.GetWord(2); // nal_ref_idc
		int nal_unit_type = bs.GetWord(5);
		if (nal_unit_type == 7)
		{
			int profile_idc = bs.GetWord(8);
			bs.GetWord(1); // constraint_set0_flag
			bs.GetWord(1); // constraint_set1_flag
			bs.GetWord(1); // constraint_set2_flag
			bs.GetWord(1); // constraint_set3_flag
			bs.GetWord(4); // reserved_zero_4bits
			bs.GetWord(8); // level_idc

			bs.GetUE(); // seq_parameter_set_id

			if (profile_idc == 100 || profile_idc == 110 ||
				profile_idc == 122 || profile_idc == 144 ||
				profile_idc == 244 || profile_idc == 44 ||
				profile_idc == 83 || profile_idc == 86 ||
				profile_idc == 118 || profile_idc == 128 ||
				profile_idc == 138)
			{
				int chroma_format_idc = bs.GetUE();
				if (chroma_format_idc > 3)
					return false;
				if (chroma_format_idc == 3)
					bs.GetWord(1); // residual_colour_transform_flag
				bs.GetUE(); // bit_depth_luma_minus8
				bs.GetUE(); // bit_depth_chroma_minus8
				bs.GetWord(1); // qpprime_y_zero_transform_bypass_flag
							   //int seq_scaling_matrix_present_flag = bs.GetWord(1);
							   //if (seq_scaling_matrix_present_flag)
				{
					uint8_t scaling_matrix4[6][16];
					uint8_t scaling_matrix8[6][64];
					decode_scaling_matrices(bs, chroma_format_idc, scaling_matrix4, scaling_matrix8);
				}
			}
			int log2_max_frame_num_minu4 = bs.GetUE(); // log2_max_frame_num_minu4
			int pic_order_cnt_type = bs.GetUE();
			if (pic_order_cnt_type == 0)
				bs.GetUE(); // log2_max_pic_order_cnt_lsb_minus4
			else if (pic_order_cnt_type == 1)
			{
				bs.GetWord(1); // delta_pic_order_always_zero_flag
				bs.GetSE(); // offset_for_non_ref_pic
				bs.GetSE(); // offset_for_top_to_bottom_field
				int num_ref_frames_in_pic_order_cnt_cycle = bs.GetUE();
				for (int i = 0; i < num_ref_frames_in_pic_order_cnt_cycle; i++)
					bs.GetSE(); // offset_for_ref_frame
			}
			bs.GetUE(); // num_ref_frames
			bs.GetWord(1); // gaps_in_frame_num_value_allowed_flag
			int pic_width_in_mbs_minus1 = bs.GetUE();
			int pic_height_in_map_units_minus1 = bs.GetUE();

			nWidth = (pic_width_in_mbs_minus1 + 1) * 16;
			nHeight = (pic_height_in_map_units_minus1 + 1) * 16;

			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		NALBitstream bs(pSps, nLen);
		// seq_parameter_set_rbsp()
		bs.GetWord(4);// sps_video_parameter_set_id
		int sps_max_sub_layers_minus1 = bs.GetWord(3);
		if (sps_max_sub_layers_minus1 > 6)
			return false;
		bs.GetWord(1);
		{
			bs.GetWord(2);
			bs.GetWord(1);
			bs.GetWord(5); // profile
			bs.GetWord(32);
			bs.GetWord(1);
			bs.GetWord(1);
			bs.GetWord(1);
			bs.GetWord(1);
			bs.GetWord(44);
			bs.GetWord(8); // general_level_idc
			uint8_t sub_layer_profile_present_flag[6] = { 0 };
			uint8_t sub_layer_level_present_flag[6] = { 0 };
			for (int i = 0; i < sps_max_sub_layers_minus1; i++)
			{
				sub_layer_profile_present_flag[i] = bs.GetWord(1);
				sub_layer_level_present_flag[i] = bs.GetWord(1);
			}
			if (sps_max_sub_layers_minus1 > 0)
			{
				for (int i = sps_max_sub_layers_minus1; i < 8; i++)
					uint8_t reserved_zero_2bits = bs.GetWord(2);
			}
			for (int i = 0; i < sps_max_sub_layers_minus1; i++)
			{
				if (sub_layer_profile_present_flag[i])
				{
					bs.GetWord(2);
					bs.GetWord(1);
					bs.GetWord(5);
					bs.GetWord(32);
					bs.GetWord(1);
					bs.GetWord(1);
					bs.GetWord(1);
					bs.GetWord(1);
					bs.GetWord(44);
				}
				if (sub_layer_level_present_flag[i])
					bs.GetWord(8); // sub_layer_level_idc[i]
			}
		}
		uint32_t sps_seq_parameter_set_id = bs.GetUE();
		if (sps_seq_parameter_set_id > 15)
			return false;
		uint32_t chroma_format_idc = bs.GetUE();
		if (sps_seq_parameter_set_id > 3)
			return false;
		if (chroma_format_idc == 3)
			bs.GetWord(1);
		nWidth = bs.GetUE(); // pic_width_in_luma_samples  
		nHeight = bs.GetUE(); // pic_height_in_luma_samples  
		if (bs.GetWord(1))
		{
			bs.GetUE();
			bs.GetUE();
			bs.GetUE();
			bs.GetUE();
		}
		uint32_t bit_depth_luma_minus8 = bs.GetUE();
		uint32_t bit_depth_chroma_minus8 = bs.GetUE();
		if (bit_depth_luma_minus8 != bit_depth_chroma_minus8)
			return false;

		return true;
	}
}

typedef enum FRAME_NAL_TYPE
{
	e_NAL_VPS,
	e_NAL_SPS,
	e_NAL_PPS,
	e_NAL_IFRAME,
	e_NAL_PFRAME,
	e_NAL_OTHER
}EN_FRAME_NAL_TYPE;

class StreamClientState {
public:
	StreamClientState();
	virtual ~StreamClientState();

public:
	MediaSubsessionIterator * iter;
	MediaSession* session;
	MediaSubsession* subsession;
	TaskToken streamTimerTask;
	double duration;
};

class ourRTSPClient : public RTSPClient
{
public:
	static ourRTSPClient* createNew(UsageEnvironment& env, char const* rtspURL,
		int verbosityLevel = 0,
		char const* applicationName = NULL,
		portNumBits tunnelOverHTTPPortNum = 0);

	string GetRtspUrl()
	{
		return m_strUrl;
	}

	bool IsCanClose()
	{
		bool blRet = false;
		pthread_mutex_lock(&m_mutex);
		blRet = m_blOpened;
		m_blOpened = false;
		pthread_mutex_unlock(&m_mutex);
		return blRet;
	}

	void SetOpened(bool blOpened)
	{
		pthread_mutex_lock(&m_mutex);
		m_blOpened = blOpened;
		pthread_mutex_unlock(&m_mutex);
	}

protected:
	ourRTSPClient(UsageEnvironment& env, char const* rtspURL,
		int verbosityLevel, char const* applicationName, portNumBits tunnelOverHTTPPortNum);
	// called only by createNew();
	virtual ~ourRTSPClient();

public:
	StreamClientState scs;
private:
	string m_strUrl;
	bool   m_blOpened;
	bool   m_blClose;
	pthread_mutex_t			m_mutex;

};

class CRtspClientStream //: public CThread
{
public:
	CRtspClientStream(void* pUser, const char* chUri, int iTcp);
	virtual ~CRtspClientStream();

	void Close(bool blAuto = false);	//�Լ��رյ�
	int  Open(UsageEnvironment* env);
	void* GetUserParam() { return m_pUser; };
	RTSPClient* GetRtspClient() { return m_pRtspClient; };
	int GetRtspTcp() { return m_iTCP; };
	int GetWaitCount()
	{
		return m_iWaitCount;
	};
	void SetWaitCount(int iWaitCount)
	{
		m_iWaitCount = iWaitCount;
	}
	bool GetOpenStatus()
	{
		return m_blOpened;
	}
	void SetReconectCount(int iCount)
	{
		m_iReconnectCount = iCount;
	}
	int GetReconnectCount()
	{
		return  m_iReconnectCount;
	}
	std::string GetUri()
	{
		return  m_strUri;
	}
private:
	int						m_iTCP;
	std::string				m_strUri;
	void*					m_pUser;
	RTSPClient*				m_pRtspClient;

	string					m_strProgramName;

	int						m_iWaitCount;				//�ȴ�����������趨ʱ�䣬�������������
	int						m_iReconnectCount;			//��������������ָ���������������ϱ�
	bool					m_blOpened;

	UsageEnvironment*		m_pEnv;

	//NALUTypeBase_H265		m_nalBaseH265;
	//FUs_H265				m_nalFUs_H265;
	//APs_H265				m_nalAPs_H265;
};
 class DummySink : public MediaSink 
 {
 public:
 	static DummySink* createNew(UsageEnvironment& env,
 		MediaSubsession& subsession, // identifies the kind of data that's being received
 		char const* streamId = NULL); // identifies the stream itself (optional)
 
 	
 
 private:
 	DummySink(UsageEnvironment& env, MediaSubsession& subsession, char const* streamId);
 	virtual ~DummySink();
 
 	static void afterGettingFrame(void* clientData, unsigned frameSize,
 		unsigned numTruncatedBytes,
 		struct timeval presentationTime,
 		unsigned durationInMicroseconds);
 	void afterGettingFrame(unsigned frameSize, unsigned numTruncatedBytes,
 		struct timeval presentationTime, unsigned durationInMicroseconds);
 
 private:
 	// redefined virtual functions:
 	virtual Boolean continuePlaying();
 
 private:
 	u_int8_t*			m_pReceiveBuffer;
 	MediaSubsession&	m_fSubsession;
 	char*				m_pStreamId;
	string				m_strStreamID;
	uint16_t			m_u16Width;
	uint16_t			m_u16Height;

	u_int8_t*			m_pFrmeTypebuf;
	uint16_t			m_ui16FrameLen;
 
 	
 	RTSP_STREAM_INFO	m_frameInfo;
 };

#endif
