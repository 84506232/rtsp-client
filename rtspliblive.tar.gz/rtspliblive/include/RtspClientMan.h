/***********************************************************************
** Copyright (C) mstar.
** Author       : andy.huang
** Date         : 2017-07-3
** Name         : RtspStreamClientMan.h
** Version      : 1.0
** Description  : RTSP���Ĺ����࣬���ڹ���uri��ÿ�����ͻ��ˡ�
** Modify Record:
1:
***********************************************************************/

#ifndef _RTSP_CLIENTMAN_H_
#define _RTSP_CLIENTMAN_H_

#include "RtspClientStream.h"
#include "RTSP_Stream_API.h"
#include "liveMedia.hh"
#include "UsageEnvironment.hh"
#include "BasicUsageEnvironment.hh"
#include "RTSPClient.hh"
#include "RTPSink.hh"
#include <pthread.h> 
#include <string>
#include <map>
#include <queue>

using namespace std;


class CRtspClientMan
{
public:
	static CRtspClientMan* Instance()
	{
		static CRtspClientMan m_stRtspClientMan;
		return &m_stRtspClientMan;
	}

	int Init(CallBack_RTSP_Func fn);
	void unInit();

 	int CreateClient(const char* strRtspAdd, CRtspClientStream* rtspClient);
 	void CloseClient(string& strUrl);
	int openURL(const char* rtspURL, void* param, int iTcp);

 	void* GetClientParam(string& strRtsp);

	void CallBackData(Rtsp_back_msg msg, RTSP_STREAM_INFO * streamInfo, string& strUrl);

	UsageEnvironment* GetEnv() 
	{
		return m_pEnv;
	};

	static void *Loop_Thread_Fun(void *param);
	static void *Check_Thread_Fun(void *param);

private:
	CRtspClientMan();
	~CRtspClientMan();

	void CheckClient();
	void LoopFunc();

	void CheckCreate();
	void CheckDel();

private:

	std::map<string, CRtspClientStream*> m_mapClient;
	vector<CRtspClientStream*> m_vecClientCreate;
	vector<string>			m_vecClientdel;
	pthread_mutex_t			m_mutex;
	pthread_mutex_t			m_mutexGen;

	TaskScheduler*			m_pScheduler;
	UsageEnvironment*		m_pEnv;
	char					m_eventLoopWatchVariable;

	bool					m_blExit;
	const int				CONST_CHECK_CONNCT;


	CallBack_RTSP_Func		m_fn;

	pthread_t				m_tid;
	pthread_t				m_tidLoop;
};

#endif