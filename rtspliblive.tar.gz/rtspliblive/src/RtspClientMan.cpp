#include "RtspClientMan.h"




CRtspClientMan::CRtspClientMan()	
	: CONST_CHECK_CONNCT(20)
	, m_fn(NULL)
	, m_blExit(false)
	, m_tid(0)
	, m_tidLoop(0)
	, m_pEnv(NULL)
	, m_pScheduler(NULL)
{
	pthread_mutex_init(&m_mutex, NULL);
	pthread_mutex_init(&m_mutexGen, NULL);
}

CRtspClientMan::~CRtspClientMan()
{
	m_blExit = true;
	pthread_mutex_destroy(&m_mutex);
	pthread_mutex_destroy(&m_mutexGen);
}

void *CRtspClientMan::Check_Thread_Fun(void *param)
{
	CRtspClientMan *pThis = (CRtspClientMan*)param;
	pThis->CheckClient();
	return NULL;
}

void *CRtspClientMan::Loop_Thread_Fun(void *param)
{
	CRtspClientMan *pThis = (CRtspClientMan*)param;
	pThis->LoopFunc();
	return NULL;
}

void CRtspClientMan::LoopFunc()
{
	if (NULL != m_pEnv)
	{
		m_pEnv->taskScheduler().doEventLoop(&m_eventLoopWatchVariable);
	}
}
//�����Ƶ�Ƿ�������������������������������2��֮�����Ӳ��ϣ�����������д������ϲ���Ҫ������
void CRtspClientMan::CheckClient()
{
	int iWaitCount = 0;
	int iReconnect = 0;
	RTSP_STREAM_INFO	frameInfo;
	frameInfo.frameType = e_LongNoStream;
	char chRet[64] = "to long no stream!";
	frameInfo.pData = (unsigned char*)chRet;
	vector<string> vecUri;
	vector<CRtspClientStream*> vecClientOpen;
	vector<CRtspClientStream*> vecClientClose;
	while (!m_blExit)
	{
		//CheckCreate();
		CheckDel();
		vecClientOpen.clear();
		vecClientClose.clear();
		vecUri.clear();
		pthread_mutex_lock(&m_mutex);
		std::map<string, CRtspClientStream*>::iterator it = m_mapClient.begin();
		while (m_mapClient.end() != it)
		{
			iWaitCount = it->second->GetWaitCount();
			iReconnect = it->second->GetReconnectCount();
			if (iWaitCount <= 0)
			{
				if (!it->second->GetOpenStatus())
				{
					vecClientOpen.push_back(it->second);
					if (iReconnect >= 2)
					{
						vecUri.push_back(it->first);
						it->second->SetReconectCount(0);
						it->second->SetWaitCount(CONST_CHECK_CONNCT);
						//it->second->Close(true);
						//m_mapClient.erase(it++);
						continue;
					}
					else
					{
						//printf("rtsp-check to open a client\n");
						//it->second->Open(m_pEnv);
						//printf("rtsp-check opened a client\n");
						it->second->SetReconectCount(++iReconnect);
					}
				}
				else
				{
					//printf("rtsp-to close a client\n");
					//it->second->Close();
					//printf("rtsp-close a client\n");
					it->second->SetWaitCount(CONST_CHECK_CONNCT);
					vecClientClose.push_back(it->second);
				}
			}
			else
			{
				it->second->SetWaitCount(--iWaitCount);
			}
			it++;
		}
		pthread_mutex_unlock(&m_mutex);
		for (int i = 0; i < vecClientOpen.size(); i++)
		{
			vecClientOpen[i]->Open(m_pEnv);
		}
		for (int i = 0; i < vecClientClose.size(); i++)
		{
			vecClientClose[i]->Close();
		}
		if (NULL != m_fn)
		{
			for (int i = 0; i < vecUri.size(); i++)
			{
				m_fn(e_connect_failed, &frameInfo, NULL, vecUri[i].c_str());
			}
		}
		usleep(500 * 1000);
	}
}



int CRtspClientMan::Init(CallBack_RTSP_Func fn)
{
	
	if (NULL == fn)
	{
		printf("init RTSP failed! callback is NULL!\n");
		return -1;
	}
	m_fn = fn;
	m_eventLoopWatchVariable = 0; //��ʼ����ֵΪ1��ֻ����0һ��
	m_pScheduler = BasicTaskScheduler::createNew();
	if (NULL == m_pScheduler)
	{
	 	printf("create BasicTaskScheduler failed!\n");
	 	return -1;
	}
	m_pEnv = BasicUsageEnvironment::createNew(*m_pScheduler);
	if (NULL == m_pEnv)
	{
	 	printf("create BasicUsageEnvironment failed!\n");
	 	return -1;
	}
	int iT = pthread_create(&m_tidLoop, NULL, Loop_Thread_Fun, this);
	if (iT)
	{
		perror("pthread_create()");
		return -1;
	}
	pthread_detach(m_tidLoop);
	m_blExit = false;
	iT = pthread_create(&m_tid, NULL, Check_Thread_Fun, this);
	if (iT)
	{
		perror("pthread_create()");
		return -1;
	}
	return 0;
}

void CRtspClientMan::CallBackData(Rtsp_back_msg msg, RTSP_STREAM_INFO * streamInfo, string& strUrl)
{
	void* pUser = NULL;
	bool blOut = true;
	pthread_mutex_lock(&m_mutex);
	std::map<string, CRtspClientStream*>::iterator it = m_mapClient.find(strUrl);
	if (m_mapClient.end() != it)
	{
		if (e_connect_failed == msg)		//����ʧ�ܣ�Ҫ���ͻ������
		{
			if (e_LongNoStream == streamInfo->frameType)
			{
				blOut = false;
			}
			else
			{
				it->second->Close(true);
				m_mapClient.erase(it);
				printf("connect failed, delete a rtsp client success, url = %s\n", strUrl.c_str());
			}
		}
		else   //�ص��������ݣ�Ҫ���µ�ǰ״̬
		{
			it->second->SetWaitCount(CONST_CHECK_CONNCT);
			pUser = it->second->GetUserParam();
		}
	}
	pthread_mutex_unlock(&m_mutex);
	if (NULL != m_fn && blOut)
	{
		m_fn(msg, streamInfo, pUser, strUrl.c_str());
	}
}

void CRtspClientMan::unInit()
{
	m_eventLoopWatchVariable = 1;
	m_blExit = true;
	if (0 != m_tid)
	{
		void **ret;
		pthread_join(m_tid, ret);
	}
	vector<CRtspClientStream*> vecDel;
	pthread_mutex_lock(&m_mutex);
	std::map<string, CRtspClientStream*>::iterator it = m_mapClient.begin();
	while (m_mapClient.end() != it)
	{
		vecDel.push_back(it->second);
		m_mapClient.erase(it++);
	}
	pthread_mutex_unlock(&m_mutex);
	for (int i = 0; i < vecDel.size(); i++)
	{
		if (NULL != vecDel[i])
		{
			vecDel[i]->Close();
		}
	}
	if (NULL != m_pScheduler)
	{
		delete m_pScheduler;
		m_pScheduler = NULL;
	}
	if (NULL != m_pEnv)
	{
		m_pEnv->reclaim();
		m_pEnv = NULL;
	}
	return;
}

int CRtspClientMan::CreateClient(const char* strRtspAdd, CRtspClientStream* rtspClient)
{
	{
		pthread_mutex_lock(&m_mutex);
		std::map<string, CRtspClientStream*>::iterator it = m_mapClient.find(strRtspAdd);
		if (m_mapClient.end() != it)
		{
			pthread_mutex_unlock(&m_mutex);
			return 0;
		}
		m_mapClient[strRtspAdd] = rtspClient;
		pthread_mutex_unlock(&m_mutex);
		printf("add a rtsp client success, url = %s\n", strRtspAdd);
	}
	return 0;
}

void CRtspClientMan::CloseClient(string& strUrl)
{
	pthread_mutex_lock(&m_mutexGen);
	m_vecClientdel.push_back(strUrl);
	pthread_mutex_unlock(&m_mutexGen);
	//pthread_mutex_lock(&m_mutex);
	//std::map<string, CRtspClientStream*>::iterator it = m_mapClient.find(strUrl);
	//if (m_mapClient.end() != it)
	//{
	//	it->second->Close();
	//	delete it->second;
	//	m_mapClient.erase(it);
	//	printf("delete a rtsp client success, url = %s\n", strUrl.c_str());
	//}
	//pthread_mutex_unlock(&m_mutex);
}

void* CRtspClientMan::GetClientParam(string& strRtsp)
{
	void* pRet = NULL;
	pthread_mutex_lock(&m_mutex);
	std::map<string, CRtspClientStream*>::iterator it = m_mapClient.find(strRtsp);
	if (m_mapClient.end() != it)
	{
		it->second->SetWaitCount(0);
		pRet = it->second->GetUserParam();
	}
	pthread_mutex_unlock(&m_mutex);
	return pRet;
}

int CRtspClientMan::openURL(const char* strUrl, void* param, int iTcp)
{
	printf("CRtspClientMan::openURL==== %s\n", strUrl);
	CRtspClientStream* pClient = new CRtspClientStream(param, strUrl, iTcp);
	if (NULL == pClient)
	{
		printf("create client failed!\n");
		return -1;
	}
	CreateClient(strUrl, pClient);
	//pthread_mutex_lock(&m_mutexGen);
	//m_vecClientCreate.push_back(pClient);
	//pthread_mutex_unlock(&m_mutexGen);
	if (0 != pClient->Open(m_pEnv))
	{
		printf("open client failed!\n");
		return -1;
	}
	pClient->SetWaitCount(40);
	
	return 0;
}

void CRtspClientMan::CheckCreate()
{
	vector<CRtspClientStream*> vecClientCreate;
	pthread_mutex_lock(&m_mutexGen);
	vecClientCreate.swap(m_vecClientCreate);
	//for (int i = 0; i < m_vecClientCreate.size(); i++)
	//{
	//	bool blFind = false;
	//	for (int j = 0; j < m_vecClientdel.size(); j++)
	//	{
	//		if (0 == m_vecClientCreate[i]->GetUri().compare(m_vecClientdel[j].c_str()))
	//		{
	//			blFind = true;
	//		}
	//	}
	//	if (!blFind)
	//	{
	//		vecClientCreate.push_back(m_vecClientCreate[i]);
	//	}
	//}
	pthread_mutex_unlock(&m_mutexGen);
	for (int i = 0; i < vecClientCreate.size(); i++)
	{
		CreateClient(vecClientCreate[i]->GetUri().c_str(), vecClientCreate[i]);
		vecClientCreate[i]->Open(m_pEnv);
		vecClientCreate[i]->SetWaitCount(40);
	}
}
void CRtspClientMan::CheckDel()
{
	vector<string> vecClientDel;
	CRtspClientStream* pDelClient = NULL;
	pthread_mutex_lock(&m_mutexGen);
	vecClientDel.swap(m_vecClientdel);
	//for (int i = 0; i < m_vecClientdel.size(); i++)
	//{
	//	bool blFind = false;
	//	for (int j = 0; j < m_vecClientCreate.size(); j++)
	//	{
	//		if (0 == m_vecClientCreate[j]->GetUri().compare(m_vecClientdel[i].c_str()))
	//		{
	//			blFind = true;
	//		}
	//	}
	//	if (!blFind)
	//	{
	//		vecClientDel.push_back(m_vecClientdel[i]);
	//	}
	//}
	pthread_mutex_unlock(&m_mutexGen);
	for (int i = 0; i < vecClientDel.size(); i++)
	{
		pDelClient = NULL;
		pthread_mutex_lock(&m_mutex);
		std::map<string, CRtspClientStream*>::iterator it = m_mapClient.find(vecClientDel[i]);
		if (m_mapClient.end() != it)
		{
			pDelClient = it->second;
			//it->second->Close();
			//delete it->second;
			m_mapClient.erase(it);
			//printf("delete a rtsp client success, url = %s\n", vecClientDel[i].c_str());
		}
		pthread_mutex_unlock(&m_mutex);
		if (NULL != pDelClient)
		{
			pDelClient->Close();
			delete pDelClient;
			pDelClient = NULL;
		}
	}
}

