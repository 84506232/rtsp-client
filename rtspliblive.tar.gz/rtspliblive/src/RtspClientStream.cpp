#include "RtspClientStream.h"
#include "RtspClientMan.h"
#include <string.h>
//
#include "liveMedia.hh"
#include "BasicUsageEnvironment.hh"

// Forward function definitions:

// RTSP 'response handlers':
void continueAfterDESCRIBE(RTSPClient* rtspClient, int resultCode, char* resultString);
void continueAfterSETUP(RTSPClient* rtspClient, int resultCode, char* resultString);
void continueAfterPLAY(RTSPClient* rtspClient, int resultCode, char* resultString);

// Other event handler functions:
void subsessionAfterPlaying(void* clientData); // called when a stream's subsession (e.g., audio or video substream) ends
void subsessionByeHandler(void* clientData); // called when a RTCP "BYE" is received for a subsession
void streamTimerHandler(void* clientData);
// called at the end of a stream's expected duration (if the stream has not already signaled its end using a RTCP "BYE")

// The main streaming routine (for each "rtsp://" URL):
//void openURL(UsageEnvironment& env, char const* progName, char const* rtspURL);

// Used to iterate through each stream's 'subsessions', setting up each one:
void setupNextSubsession(RTSPClient* rtspClient);

// Used to shut down and close a stream (including its "RTSPClient" object):
void shutdownStream(RTSPClient* rtspClient, EN_RTSP_BACK_ERRCODE exitCode, char* resultString);

// A function that outputs a string that identifies each stream (for debugging output).  Modify this if you wish:
UsageEnvironment& operator<<(UsageEnvironment& env, const RTSPClient& rtspClient) 
{
	return env << "[URL:\"" << rtspClient.url() << "\"]: ";
}

// A function that outputs a string that identifies each subsession (for debugging output).  Modify this if you wish:
UsageEnvironment& operator<<(UsageEnvironment& env, const MediaSubsession& subsession) {
	return env << subsession.mediumName() << "/" << subsession.codecName();
}

void usage(UsageEnvironment& env, char const* progName) {
	env << "Usage: " << progName << " <rtsp-url-1> ... <rtsp-url-N>\n";
	env << "\t(where each <rtsp-url-i> is a \"rtsp://\" URL)\n";
}

char eventLoopWatchVariable = 0;

// Define a class to hold per-stream state that we maintain throughout each stream's lifetime:

#define RTSP_CLIENT_VERBOSITY_LEVEL 1 // by default, print verbose output from each "RTSPClient"

void continueAfterDESCRIBE(RTSPClient* rtspClient, int resultCode, char* resultString) 
{
	EN_RTSP_BACK_ERRCODE enCode = e_OK;
	char* pChResult = new char[strlen(resultString) + 1];
	if (NULL != pChResult)
	{
		strcpy(pChResult, resultString);
	}
	do 
	{
		UsageEnvironment& env = rtspClient->envir(); // alias
		StreamClientState& scs = ((ourRTSPClient*)rtspClient)->scs; // alias

		if (resultCode != 0) 
		{
			env << *rtspClient << "Failed to get a SDP description: " << resultString << "\n";
			enCode = e_GetSDPErr;
			delete[] resultString;
			break;
		}

		char* const sdpDescription = resultString;
		env << *rtspClient << "Got a SDP description:\n" << sdpDescription << "\n";

		// Create a media session object from this SDP description:
		scs.session = MediaSession::createNew(env, sdpDescription);
		delete[] sdpDescription; // because we don't need it anymore
		if (scs.session == NULL) 
		{
			env << *rtspClient << "Failed to create a MediaSession object from the SDP description: " << env.getResultMsg() << "\n";
			enCode = e_NoMediaSession;
			break;
		}
		else if (!scs.session->hasSubsessions()) 
		{
			env << *rtspClient << "This session has no media subsessions (i.e., no \"m=\" lines)\n";
			enCode = e_NoSubSession;
			break;
		}
		// Then, create and set up our data source objects for the session.  We do this by iterating over the session's 'subsessions',
		// calling "MediaSubsession::initiate()", and then sending a RTSP "SETUP" command, on each one.
		// (Each 'subsession' will have its own data source.)
		scs.iter = new MediaSubsessionIterator(*scs.session);
		setupNextSubsession(rtspClient);
		if (NULL != pChResult)
		{
			delete[] pChResult;
			pChResult = NULL;
		}
		return;
	} while (0);
	shutdownStream(rtspClient, enCode, pChResult);
	if (NULL != pChResult)
	{
		delete[] pChResult;
		pChResult = NULL;
	}
}

// By default, we request that the server stream its data using RTP/UDP.
// If, instead, you want to request that the server stream via RTP-over-TCP, change the following to True:
#define REQUEST_STREAMING_OVER_TCP True

void setupNextSubsession(RTSPClient* rtspClient) 
{
	UsageEnvironment& env = rtspClient->envir(); // alias
	StreamClientState& scs = ((ourRTSPClient*)rtspClient)->scs; // alias

	scs.subsession = scs.iter->next();
	if (scs.subsession != NULL)
	{
		if (!scs.subsession->initiate()) 
		{
			env << *rtspClient << "Failed to initiate the \"" << *scs.subsession << "\" subsession: " << env.getResultMsg() << "\n";
			setupNextSubsession(rtspClient); // give up on this subsession; go to the next one
		}
		else if (memcmp("video", scs.subsession->mediumName(), 5) != 0 && memcmp("audio", scs.subsession->mediumName(), 5) != 0)
		{
			printf("not to establish this session, session name = %s\n", scs.subsession->mediumName());
			setupNextSubsession(rtspClient);
		}
		else
		{
			env << *rtspClient << "Initiated the \"" << *scs.subsession << "\" subsession (";
			if (scs.subsession->rtcpIsMuxed()) 
			{
				env << "client port " << scs.subsession->clientPortNum();
			}
			else
			{
				env << "client ports " << scs.subsession->clientPortNum() << "-" << scs.subsession->clientPortNum() + 1;
			}
			env << ")\n";

			// Continue setting up this subsession, by sending a RTSP "SETUP" command:
			rtspClient->sendSetupCommand(*scs.subsession, continueAfterSETUP, False, REQUEST_STREAMING_OVER_TCP);
		}
		return;
	}

	// We've finished setting up all of the subsessions.  Now, send a RTSP "PLAY" command to start the streaming:
	if (scs.session->absStartTime() != NULL)
	{
		// Special case: The stream is indexed by 'absolute' time, so send an appropriate "PLAY" command:
		rtspClient->sendPlayCommand(*scs.session, continueAfterPLAY, scs.session->absStartTime(), scs.session->absEndTime());
	}
	else 
	{
		scs.duration = scs.session->playEndTime() - scs.session->playStartTime();
		rtspClient->sendPlayCommand(*scs.session, continueAfterPLAY);
	}
}

void continueAfterSETUP(RTSPClient* rtspClient, int resultCode, char* resultString)
{
	do 
	{
		UsageEnvironment& env = rtspClient->envir(); // alias
		StreamClientState& scs = ((ourRTSPClient*)rtspClient)->scs; // alias

		if (resultCode != 0) 
		{
			env << *rtspClient << "Failed to set up the \"" << *scs.subsession << "\" subsession: " << resultString << "\n";
			break;
		}

		env << *rtspClient << "Set up the \"" << *scs.subsession << "\" subsession (";
		if (scs.subsession->rtcpIsMuxed()) 
		{
			env << "client port " << scs.subsession->clientPortNum();
		}
		else 
		{
			env << "client ports " << scs.subsession->clientPortNum() << "-" << scs.subsession->clientPortNum() + 1;
		}
		env << ")\n";
		ourRTSPClient* pClient = (ourRTSPClient*)rtspClient;
		scs.subsession->sink = DummySink::createNew(env, *scs.subsession, pClient->GetRtspUrl().c_str());
		// perhaps use your own custom "MediaSink" subclass instead
		if (scs.subsession->sink == NULL)
		{
			env << *rtspClient << "Failed to create a data sink for the \"" << *scs.subsession
				<< "\" subsession: " << env.getResultMsg() << "\n";
			break;
		}

		env << *rtspClient << "Created a data sink for the \"" << *scs.subsession << "\" ======subsession url: " << rtspClient->url() << "\n";
		scs.subsession->miscPtr = rtspClient; // a hack to let subsession handler functions get the "RTSPClient" from the subsession 
		scs.subsession->sink->startPlaying(*(scs.subsession->readSource()),
			subsessionAfterPlaying, scs.subsession);
		// Also set a handler to be called if a RTCP "BYE" arrives for this subsession:
		if (scs.subsession->rtcpInstance() != NULL)
		{
			scs.subsession->rtcpInstance()->setByeHandler(subsessionByeHandler, scs.subsession);
		}
	} while (0);
	delete[] resultString;

	// Set up the next subsession, if any:
	setupNextSubsession(rtspClient);
}

void continueAfterPLAY(RTSPClient* rtspClient, int resultCode, char* resultString) 
{
	Boolean success = False;
	EN_RTSP_BACK_ERRCODE enCode = e_OK;
	do
	{
		UsageEnvironment& env = rtspClient->envir(); // alias
		StreamClientState& scs = ((ourRTSPClient*)rtspClient)->scs; // alias

		if (resultCode != 0)
		{
			env << *rtspClient << "Failed to start playing session: " << resultString << "\n";
			enCode = e_PlayErr;
			break;
		}

		// Set a timer to be handled at the end of the stream's expected duration (if the stream does not already signal its end
		// using a RTCP "BYE").  This is optional.  If, instead, you want to keep the stream active - e.g., so you can later
		// 'seek' back within it and do another RTSP "PLAY" - then you can omit this code.
		// (Alternatively, if you don't want to receive the entire stream, you could set this timer for some shorter value.)
		if (scs.duration > 0) 
		{
			unsigned const delaySlop = 2; // number of seconds extra to delay, after the stream's expected duration.  (This is optional.)
			scs.duration += delaySlop;
			unsigned uSecsToDelay = (unsigned)(scs.duration * 1000000);
			scs.streamTimerTask = env.taskScheduler().scheduleDelayedTask(uSecsToDelay, (TaskFunc*)streamTimerHandler, rtspClient);
		}

		env << *rtspClient << "Started playing session";
		if (scs.duration > 0)
		{
			env << " (for up to " << scs.duration << " seconds)";
		}
		env << "...\n";

		success = True;
	} while (0);
	if (!success)
	{
		shutdownStream(rtspClient, enCode, resultString);
	}
	delete[] resultString;
}


// Implementation of the other event handlers:

void subsessionAfterPlaying(void* clientData)
{
	EN_RTSP_BACK_ERRCODE enCode = e_OK;
	MediaSubsession* subsession = (MediaSubsession*)clientData;
	RTSPClient* rtspClient = (RTSPClient*)(subsession->miscPtr);

	// Begin by closing this subsession's stream:
	Medium::close(subsession->sink);
	subsession->sink = NULL;

	// Next, check whether *all* subsessions' streams have now been closed:
	MediaSession& session = subsession->parentSession();
	MediaSubsessionIterator iter(session);
	while ((subsession = iter.next()) != NULL) 
	{
		if (subsession->sink != NULL) return; // this subsession is still active
	}

	// All subsessions' streams have now been closed, so shutdown the client:
	char chExitDes[64] = "server close this stream!\n";
	shutdownStream(rtspClient, enCode, chExitDes);
}

void subsessionByeHandler(void* clientData) 
{
	MediaSubsession* subsession = (MediaSubsession*)clientData;
	RTSPClient* rtspClient = (RTSPClient*)subsession->miscPtr;
	UsageEnvironment& env = rtspClient->envir(); // alias

	env << *rtspClient << "Received RTCP \"BYE\" on \"" << *subsession << "\" subsession\n";

	// Now act as if the subsession had closed:
	subsessionAfterPlaying(subsession);
}

void streamTimerHandler(void* clientData)
{
	EN_RTSP_BACK_ERRCODE enCode = e_LongNoStream;
	ourRTSPClient* rtspClient = (ourRTSPClient*)clientData;
	StreamClientState& scs = rtspClient->scs; // alias

	scs.streamTimerTask = NULL;
	// Shut down the stream:
	char chExitDes[64] = "is time to close stream!\n";
	shutdownStream(rtspClient, enCode, chExitDes);
}

void shutdownStream(RTSPClient* rtspClient, EN_RTSP_BACK_ERRCODE exitCode , char* resultString)
{
	printf("exit code = %d, resultString : %s\n", exitCode, resultString);
	ourRTSPClient* ourRtspClient = (ourRTSPClient*)rtspClient;
	string strUrl = "";
	{
		strUrl = ourRtspClient->GetRtspUrl();
		if (!ourRtspClient->IsCanClose())
		{
			//RTSP_STREAM_INFO	frameInfo;
			//frameInfo.frameType = exitCode;
			//CRtspClientMan::Instance()->CallBackData(e_connect_failed, &frameInfo, strUrl);
			return;
		}
	}
	UsageEnvironment& env = rtspClient->envir(); // alias
	StreamClientState& scs = ((ourRTSPClient*)rtspClient)->scs; // alias													// First, check whether any subsessions have still to be closed:
	if (scs.session != NULL) 
	{
		Boolean someSubsessionsWereActive = False;
		MediaSubsessionIterator iter(*scs.session);
		MediaSubsession* subsession;

		while ((subsession = iter.next()) != NULL)
		{
			if (subsession->sink != NULL) 
			{
				Medium::close(subsession->sink);
				subsession->sink = NULL;
				if (subsession->rtcpInstance() != NULL) 
				{
					subsession->rtcpInstance()->setByeHandler(NULL, NULL); // in case the server sends a RTCP "BYE" while handling "TEARDOWN"
				}
				someSubsessionsWereActive = True;
			}
		}
		if (someSubsessionsWereActive) 
		{
			// Send a RTSP "TEARDOWN" command, to tell the server to shutdown the stream.
			// Don't bother handling the response to the "TEARDOWN".
			rtspClient->sendTeardownCommand(*scs.session, NULL);
		}
	}
	env << *rtspClient << "Closing the stream." << strUrl.c_str() << "\n";
	Medium::close(rtspClient);
	if (e_Stream_normal_close != exitCode)
	{
		RTSP_STREAM_INFO	frameInfo;
		frameInfo.frameType = exitCode;
		frameInfo.pData = (unsigned char*)resultString;
		CRtspClientMan::Instance()->CallBackData(e_connect_failed, &frameInfo, strUrl);
	}
	// Note that this will also cause this stream's "StreamClientState" structure to get reclaimed.
}

// Implementation of "ourRTSPClient":

ourRTSPClient* ourRTSPClient::createNew(UsageEnvironment& env, char const* rtspURL,
	int verbosityLevel, char const* applicationName, portNumBits tunnelOverHTTPPortNum)
{
	return new ourRTSPClient(env, rtspURL, verbosityLevel, applicationName, tunnelOverHTTPPortNum);
}

ourRTSPClient::ourRTSPClient(UsageEnvironment& env, char const* rtspURL,
	int verbosityLevel, char const* applicationName, portNumBits tunnelOverHTTPPortNum)
	: RTSPClient(env, rtspURL, verbosityLevel, applicationName, tunnelOverHTTPPortNum, -1)
	, m_strUrl(rtspURL)
	, m_blOpened(true)
{
	pthread_mutex_init(&m_mutex, NULL);
}

ourRTSPClient::~ourRTSPClient() 
{
	pthread_mutex_destroy(&m_mutex);
}
// Implementation of "StreamClientState":

StreamClientState::StreamClientState()
	: iter(NULL), session(NULL), subsession(NULL), streamTimerTask(NULL), duration(0.0)
{
}

StreamClientState::~StreamClientState() 
{
	if (session != NULL) 
	{
		// We also need to delete "session", and unschedule "streamTimerTask" (if set)
		UsageEnvironment& env = session->envir(); // alias

		env.taskScheduler().unscheduleDelayedTask(streamTimerTask);
		Medium::close(session);
	}
	delete iter;
}
// Implementation of "DummySink":

// Even though we're not going to be doing anything with the incoming data, we still need to receive it.
// Define the size of the buffer that we'll use:
#define DUMMY_SINK_RECEIVE_BUFFER_SIZE 1024 * 1024
#define DUMMY_SINK_FRAME_BEFORE_SPS_SIZE 2 * 1024			//��δ��ȡ��sps��Ϣ֮ǰ�洢����Ϣ����ȡ���˺�ͽ����ͷ�, ���2k

DummySink* DummySink::createNew(UsageEnvironment& env, MediaSubsession& subsession, char const* streamId) 
{
	return new DummySink(env, subsession, streamId);
}

DummySink::DummySink(UsageEnvironment& env, MediaSubsession& subsession, char const* streamId)
	: MediaSink(env)
	, m_fSubsession(subsession)
	, m_u16Width(0)
	, m_u16Height(0)
	, m_ui16FrameLen(0)
{
	m_pStreamId = strDup(streamId);
	m_pReceiveBuffer = new u_int8_t[DUMMY_SINK_RECEIVE_BUFFER_SIZE + 4];
	m_pFrmeTypebuf = new u_int8_t[DUMMY_SINK_FRAME_BEFORE_SPS_SIZE];
	if (NULL == m_pReceiveBuffer || NULL == m_pFrmeTypebuf)
	{
		printf("apply recive buf failed!\n");
	}
	m_pReceiveBuffer[0] = 0;
	m_pReceiveBuffer[1] = 0;
	m_pReceiveBuffer[2] = 0;
	m_pReceiveBuffer[3] = 1;
	memset(&m_frameInfo, 0, sizeof(RTSP_STREAM_INFO));
	//test
	// 	m_iCount = 0;
	// 	std::string strTemp = fStreamId;
	// 	strTemp = strTemp.substr(19, 12);
	// 	char chTemp[100] = { 0 };
	// 	sprintf(chTemp, "stream_ch_%s.es", strTemp.c_str());
	// 	m_pFile = fopen(chTemp, "wb+");//fopen("/home/andy.huang/onviftest/onvifTest/testRtsp/stream.avi", "wb+");
	// 	if (m_pFile == NULL)
	// 	{
	// 		printf("not write file! open failed! file name = %s\n", chTemp);
	// 	}
	// 	else
	// 	{
	// 		printf("open file ok file name = %s\n", chTemp);
	// 	}
}

DummySink::~DummySink()
{
	if (NULL != m_pReceiveBuffer)
	{
		delete[] m_pReceiveBuffer;
		m_pReceiveBuffer = NULL;
	}
	if (NULL != m_pStreamId)
	{
		delete[] m_pStreamId;
		m_pStreamId = NULL;
	}
	if (NULL != m_pFrmeTypebuf)
	{
		delete[] m_pFrmeTypebuf;
		m_pFrmeTypebuf = NULL;
	}
}

void DummySink::afterGettingFrame(void* clientData, unsigned frameSize, unsigned numTruncatedBytes,
	struct timeval presentationTime, unsigned durationInMicroseconds)
{
	DummySink* sink = (DummySink*)clientData;
	sink->afterGettingFrame(frameSize, numTruncatedBytes, presentationTime, durationInMicroseconds);
}

// If you don't want to see debugging output for each received frame, then comment out the following line:
#define DEBUG_PRINT_EACH_RECEIVED_FRAME 0

EN_FRAME_NAL_TYPE GetH26xKeyFrame(bool blH264, uint8_t* pData, unsigned long ulLenth)
{
	EN_FRAME_NAL_TYPE iRet = e_NAL_PFRAME;
	if (NULL == pData || 4 > ulLenth)
	{
		return iRet;
	}
	uint8_t naluType = pData[0];
	if (blH264)
	{
		//if ((naluType & 0x1F) >= 0x05 &&
		//	(naluType & 0x1F) <= 0x08)
		//	iRet = e_NAL_IFRAME;
		//printf("frame type =  %d\n", iRet);
		uint8_t nt = pData[0] & 0x1F;
		uint8_t ft = pData[0] & 0x1F;
		if (nt == 0x1C) // FU A
			ft = pData[1] & 0x1F;
		switch (ft)
		{
		case 5: 
			iRet = e_NAL_IFRAME;
			break;
		case 7:
			iRet = e_NAL_SPS;
			break;
		case 8:
			iRet = e_NAL_PPS;
			break;
		default:
			break;
		}
	}
	else
	{
		naluType = ((naluType & 0x7E) >> 1);
		if ((naluType >= 0x10 && naluType <= 0x15) ||
			(naluType >= 0x23 && naluType <= 0x26))
		{
			iRet = e_NAL_IFRAME;
		}
		else if (0x20 == naluType)
		{
			iRet = e_NAL_VPS;
		}
		else if (0x21 == naluType)
		{
			iRet = e_NAL_SPS;
		}
		else if (0x22 == naluType)
		{
			iRet = e_NAL_PPS;
		}
	}
	return iRet;
}

void DummySink::afterGettingFrame(unsigned frameSize, unsigned numTruncatedBytes,
	struct timeval presentationTime, unsigned durationInMicroseconds)
{
	// We've just received a frame of data.  (Optionally) print out information about it:
//#ifdef DEBUG_PRINT_EACH_RECEIVED_FRAME
//	if (fStreamId != NULL) envir() << "Stream \"" << fStreamId << "\"; ";
//	envir() << fSubsession.mediumName() << "/" << fSubsession.codecName() << ":\tReceived " << frameSize << " bytes";
//	if (numTruncatedBytes > 0) envir() << " (with " << numTruncatedBytes << " bytes truncated)";
//	char uSecsStr[6 + 1]; // used to output the 'microseconds' part of the presentation time
//	sprintf(uSecsStr, "%06u", (unsigned)presentationTime.tv_usec);
//	envir() << ".\tPresentation time: " << (int)presentationTime.tv_sec << "." << uSecsStr;
//	if (fSubsession.rtpSource() != NULL && !fSubsession.rtpSource()->hasBeenSynchronizedUsingRTCP())
//	{
//		envir() << "!"; // mark the debugging output to indicate that this presentation time is not RTCP-synchronized
//	}
//#ifdef DEBUG_PRINT_NPT
//	envir() << "\tNPT: " << fSubsession.getNormalPlayTime(presentationTime);
//#endif
//	envir() << "\n";
//#endif
	//����DUMMY_SINK_RECEIVE_BUFFER_SIZE��������Ϊ�Ƿ����ݣ������⴫
	EN_FRAME_NAL_TYPE nalType;
	if (DUMMY_SINK_RECEIVE_BUFFER_SIZE < frameSize || 0 == frameSize)
	{
		printf("frame size is too big than %d!\n", DUMMY_SINK_RECEIVE_BUFFER_SIZE);
		//return;
	}
	else
	{
		//printf("fSubsession.mediumName() = %s, fSubsession.codecName() = %s\n", fSubsession.mediumName(), fSubsession.codecName());
		/*int64_t iTime = presentationTime.tv_sec * 1000 + presentationTime.tv_usec;
		if (m_frameInfo.time == iTime)
		{
			memcpy(fReceiveBufferOutFrame + m_frameInfo.length, fReceiveBuffer, frameSize);
			m_frameInfo.length += frameSize;
			printf("m_frameInfo.height = %d, m_frameInfo.width = %d, m_frameInfo.length = %d; iTime = %ld\n", m_frameInfo.height, m_frameInfo.width, m_frameInfo.length, iTime);
		}
		else
		{*/
		m_frameInfo.time = presentationTime.tv_sec * 1000000 + presentationTime.tv_usec;//convertToRTPTimestamp(presentationTime);	
		m_frameInfo.pStreamID = m_pStreamId;
		string strUrl = m_pStreamId;
		do
		{
			if (0 == strcmp("video", m_fSubsession.mediumName()))
			{
				if (0 == strcmp("H264", m_fSubsession.codecName()))
				{
					m_frameInfo.frameType = e_H264;
				}
				else if (0 == strcmp("H265", m_fSubsession.codecName()))
				{
					m_frameInfo.frameType = e_H265;
				}
				else
				{
					printf("recieve video data not h26x\n");
				}
				
                unsigned int num = 0;
                unsigned char nalu_header[4] = { 0, 0, 0, 1 };
                unsigned char extraData[256];
                
				SPropRecord *pSPropRecord;
                pSPropRecord = parseSPropParameterSets(m_fSubsession.fmtp_spropparametersets(), num);

                unsigned int extraLen;
                extraLen = 0;
                
                //p_record[0] is sps
                //p+record[1] is pps
                for(unsigned int i = 0; i < num; i++){
                    memcpy(&m_pFrmeTypebuf[extraLen], &nalu_header[0], 4);
                    extraLen += 4;
                    memcpy(&m_pFrmeTypebuf[extraLen], pSPropRecord[i].sPropBytes, pSPropRecord[i].sPropLength);
                    extraLen += pSPropRecord[i].sPropLength;
                }
                //printf("%s: %x\n",m_pStreamId,m_pReceiveBuffer[4]);
                //printf("num: %d,m_pFrmeTypebuf: %x,m_pReceiveBuffer: %x\n",num,m_pFrmeTypebuf[4],m_pReceiveBuffer[4]);
                if(m_pReceiveBuffer[4] == 0x65) //I֡
                {
                    ParseResolutionFromSps(m_pFrmeTypebuf, frameSize + 4, m_u16Width, m_u16Height, m_frameInfo.frameType == e_H264 ? 0 : 1);
                    
                    m_frameInfo.keyFrame = 1;

                    m_frameInfo.length = extraLen;
                    m_frameInfo.pData = (unsigned char *)m_pFrmeTypebuf;
                    m_frameInfo.height = m_u16Height;
                    m_frameInfo.width = m_u16Width;
                    m_frameInfo.keyFrame = 1;
                    CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);

                    memset(&m_frameInfo, 0, sizeof(RTSP_STREAM_INFO));
                    m_frameInfo.keyFrame = 1;
                    m_frameInfo.length = frameSize + 4;
                    m_frameInfo.pData = (unsigned char *)m_pReceiveBuffer;

                    m_frameInfo.height = m_u16Height;
                    m_frameInfo.width = m_u16Width;
                    CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);
                    
                    
                }
                else if(m_pReceiveBuffer[4] == 0x41) //P֡
                {
                    m_frameInfo.keyFrame = 0;
                    m_frameInfo.length = frameSize + 4;
                    m_frameInfo.pData = (unsigned char *)m_pReceiveBuffer;

                    m_frameInfo.height = m_u16Height;
                    m_frameInfo.width = m_u16Width;
                    CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);
                }
                
                memset(&m_frameInfo, 0, sizeof(RTSP_STREAM_INFO));
				#if 0
				nalType = GetH26xKeyFrame(e_H264 == m_frameInfo.frameType, extraData + 4, frameSize);
				if (e_NAL_SPS == nalType)
				{
					ParseResolutionFromSps(m_pReceiveBuffer, frameSize + 4, m_u16Width, m_u16Height, m_frameInfo.frameType == e_H264 ? 0 : 1);
					if (m_ui16FrameLen > 0 && NULL != m_pFrmeTypebuf)
					{
						m_frameInfo.length = m_ui16FrameLen;
						m_frameInfo.pData = (unsigned char *)m_pFrmeTypebuf;
						m_frameInfo.height = m_u16Height;
						m_frameInfo.width = m_u16Width;
						m_frameInfo.keyFrame = 1;
						CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);
						m_ui16FrameLen = 0;
					}
				}
				else if ((0 == m_u16Width || 0 == m_u16Height) && e_NAL_IFRAME != nalType 
					&& e_NAL_PFRAME != nalType && NULL != m_pFrmeTypebuf && DUMMY_SINK_FRAME_BEFORE_SPS_SIZE >= frameSize + m_ui16FrameLen)
				{
					memcpy(m_pFrmeTypebuf + m_ui16FrameLen, m_pReceiveBuffer, frameSize);
					m_ui16FrameLen += frameSize;
					break;
				}
				m_frameInfo.keyFrame = 0;
				if (e_NAL_PFRAME != nalType)
				{
					m_frameInfo.keyFrame = 1;
				}
				#endif
			}
			else if (0 == strcmp("audio", m_fSubsession.mediumName()))
			{
				m_frameInfo.frameType = e_Audio;
			}
			else
			{
				printf("not the video or audio data!name = %s\n", m_fSubsession.mediumName());
				//m_frameInfo.pData = NULL;
				//CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);
				//break;
			}
			#if 0
			m_frameInfo.length = frameSize + 4;
			m_frameInfo.pData = (unsigned char *)m_pReceiveBuffer;
			//if (m_frameInfo.frameType != e_Audio)
			//{
			//	if ((m_frameInfo.frameType == e_H264 && m_frameInfo.pData[4] == 0x67) ||
			//		(m_frameInfo.frameType == e_H265 && m_frameInfo.pData[4] == 0x42))
			//		ParseResolutionFromSps(m_frameInfo.pData, m_frameInfo.length, m_u16Width, m_u16Height, m_frameInfo.frameType == e_H264 ? 0 : 1);
			//}
			m_frameInfo.height = m_u16Height;
			m_frameInfo.width = m_u16Width;
			CRtspClientMan::Instance()->CallBackData(e_stream_data, &m_frameInfo, strUrl);
			memset(&m_frameInfo, 0, sizeof(RTSP_STREAM_INFO));
			#endif
		} while (0);
		
	}
	// Then continue, to request the next frame of data:
	continuePlaying();
}

Boolean DummySink::continuePlaying()
{
	if (fSource == NULL) return False; // sanity check (should not happen)
									   // Request the next frame of data from our input source.  "afterGettingFrame()" will get called later, when it arrives:
	fSource->getNextFrame(m_pReceiveBuffer + 4, DUMMY_SINK_RECEIVE_BUFFER_SIZE,
		afterGettingFrame, this,
		onSourceClosure, this);
	return True;
}


CRtspClientStream::CRtspClientStream(void* pUser, const char* chUri, int iTcp)
	: m_iTCP(iTcp)
	, m_pUser(pUser)			//pUser ��ʱû���ô���ʹ����������ʶuser
	, m_strUri(chUri)
	, m_pRtspClient(NULL)
	, m_iWaitCount(0)
	, m_blOpened(false)
	, m_iReconnectCount(0)
	, m_pEnv(NULL)
{
	pthread_mutex_init(&m_mutex, NULL);
}

CRtspClientStream::~CRtspClientStream()
{
	pthread_mutex_destroy(&m_mutex);
}

int CRtspClientStream::Open(UsageEnvironment* env)
{
	pthread_mutex_lock(&m_mutex);
	if (NULL != m_pRtspClient && m_blOpened)
	{
		pthread_mutex_unlock(&m_mutex);
		return -1;
	}
	string strProgName = "Linux";
	printf("CRtspClientStream::openURL==== %s\n", m_strUri.c_str());
	m_pRtspClient = ourRTSPClient::createNew(*env, m_strUri.c_str(), RTSP_CLIENT_VERBOSITY_LEVEL, strProgName.c_str());
	if (m_pRtspClient == NULL)
	{
		*env << "Failed to create a RTSP client for URL \"" << m_strUri.c_str() << "\": " << env->getResultMsg() << "\n";
		pthread_mutex_unlock(&m_mutex);
		return -1;
	}
	m_blOpened = true;
	m_pEnv = env;
	m_iWaitCount = 40;
	pthread_mutex_unlock(&m_mutex);
	m_pRtspClient->sendDescribeCommand(continueAfterDESCRIBE);
	return 0;
}

void CRtspClientStream::Close(bool blAuto)
{
	pthread_mutex_lock(&m_mutex);
	if (!m_blOpened)
	{
		pthread_mutex_unlock(&m_mutex);
		return;
	}
	m_blOpened = false;
	pthread_mutex_unlock(&m_mutex);
	if (!blAuto)
	{
		StreamClientState& scs = ((ourRTSPClient*)m_pRtspClient)->scs; // alias

		unsigned const delaySlop = 2; // number of seconds extra to delay, after the stream's expected duration.  (This is optional.)
		scs.duration = delaySlop;
		unsigned uSecsToDelay = 0;//(unsigned)(scs.duration * 1000000);
		scs.streamTimerTask = m_pEnv->taskScheduler().scheduleDelayedTask(uSecsToDelay, (TaskFunc*)streamTimerHandler, m_pRtspClient);
		//shutdownStream(m_pRtspClient, e_Stream_normal_close, NULL);
	}
	else
	{
		m_pRtspClient = NULL;
	}
}


