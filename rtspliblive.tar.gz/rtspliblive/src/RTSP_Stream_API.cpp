#include "RTSP_Stream_API.h"
#include "RtspClientMan.h"


int RTSP_Stream_Init(CallBack_RTSP_Func fn)
{
	return CRtspClientMan::Instance()->Init(fn);
}


void RTSP_Stream_UnInit()
{
	CRtspClientMan::Instance()->unInit();
}

int RTSP_Open_Stream(const char* pchUri, const char* userName, const char* pwd, void* param, int iTcp)
{
	return CRtspClientMan::Instance()->openURL(pchUri, param, iTcp);
}

void RTSP_Close_Stream(const char* pchUri)
{
	std::string strUrl = pchUri;
	CRtspClientMan::Instance()->CloseClient(strUrl);
}

int RTSP_GetStream(const char* pchUri, RTSP_STREAM_INFO* pStreamInfo)
{
	//CRtspClientMan::Instance()->SetStart();
	return 0;
	//return CRtspClientMan::Instance()->GetClientStream(pchUri, pStreamInfo);
}
